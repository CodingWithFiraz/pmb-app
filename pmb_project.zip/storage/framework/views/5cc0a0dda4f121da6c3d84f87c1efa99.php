<?php $__env->startSection('title', 'Daftar Pendaftar'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold">Daftar Pendaftar</h1>
    <a href="<?php echo e(route('admin.pendaftaran.export', request()->query())); ?>"
        class="bg-green-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-green-700 text-sm">
        Export CSV
    </a>
</div>


<form method="GET" class="bg-white shadow rounded-xl p-4 mb-6 flex gap-3 flex-wrap">
    <input type="text" name="search" value="<?php echo e(request('search')); ?>"
        placeholder="Cari nama / nomor / email..."
        class="border rounded-lg px-3 py-2 text-sm flex-1 min-w-48 focus:ring-2 focus:ring-blue-500">

    <select name="periode_id" class="border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500">
        <option value="">Semua Periode</option>
        <?php $__currentLoopData = $periode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($p->id); ?>" <?php echo e((int) request('periode_id') === $p->id ? 'selected' : ''); ?>>
                <?php echo e($p->nama); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <select name="jalur_id" class="border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500">
        <option value="">Semua Jalur</option>
        <?php $__currentLoopData = $jalur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($j->id); ?>" <?php echo e((int) request('jalur_id') === $j->id ? 'selected' : ''); ?>>
                <?php echo e($j->kode); ?> - <?php echo e($j->nama); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <select name="status" class="border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500">
        <option value="">Semua Status</option>
        <?php $__currentLoopData = [
            'draft'               => 'Draft',
            'menunggu_verifikasi' => 'Menunggu Verifikasi',
            'terverifikasi'       => 'Terverifikasi',
            'ditolak'             => 'Ditolak',
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value); ?>" <?php echo e(request('status') === $value ? 'selected' : ''); ?>><?php echo e($label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700">Filter</button>
    <a href="<?php echo e(route('admin.pendaftaran.index')); ?>" class="border border-gray-300 text-gray-600 px-4 py-2 rounded-lg text-sm hover:bg-gray-50">Reset</a>
</div>

<div class="bg-white shadow rounded-xl overflow-hidden">
    <table class="w-full text-sm">
        <thead class="bg-gray-50 text-gray-600">
            <tr>
                <th class="text-left px-4 py-3">No. Daftar</th>
                <th class="text-left px-4 py-3">Nama</th>
                <th class="text-left px-4 py-3">Program Studi</th>
                <th class="text-left px-4 py-3">Jalur</th>
                <th class="text-left px-4 py-3">Periode</th>
                <th class="text-left px-4 py-3">Status</th>
                <th class="px-4 py-3"></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $pendaftaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-t hover:bg-gray-50">
                    <td class="px-4 py-3 font-mono text-xs"><?php echo e($p->nomor_pendaftaran ?? '-'); ?></td>
                    <td class="px-4 py-3 font-medium"><?php echo e($p->user->name); ?></td>
                    <td class="px-4 py-3 text-gray-600"><?php echo e($p->prodi->nama); ?></td>
                    <td class="px-4 py-3 text-gray-600"><?php echo e($p->jalur->kode); ?></td>
                    <td class="px-4 py-3 text-gray-600"><?php echo e($p->periode->tahun_akademik); ?></td>
                    <td class="px-4 py-3">
                        <span class="px-2 py-0.5 rounded text-xs font-medium
                            <?php if($p->status === 'terverifikasi'): ?>
                                bg-green-100 text-green-700
                            <?php elseif($p->status === 'ditolak'): ?>
                                bg-red-100 text-red-700
                            <?php elseif($p->status === 'menunggu_verifikasi'): ?>
                                bg-amber-100 text-amber-700
                            <?php else: ?>
                                bg-gray-100 text-gray-700
                            <?php endif; ?>">
                            <?php echo e($p->statusLabel()); ?>

                        </span>
                    </td>
                    <td class="px-4 py-3">
                        <a href="<?php echo e(route('admin.pendaftaran.show', $p)); ?>" class="text-blue-600 hover:underline">Detail</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-center py-8 text-gray-500">Tidak ada data.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-4"><?php echo e($pendaftaran->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/admin/pendaftaran/index.blade.php ENDPATH**/ ?>