<?php $__env->startSection('title', 'Edit Periode PMB'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-lg mx-auto">
    <h1 class="text-2xl font-bold mb-6">Edit Periode PMB</h1>
    <div class="bg-white shadow rounded-xl p-6">
        <form method="POST" action="<?php echo e(route('admin.periode.update', $periode)); ?>">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <div class="mb-4">
                <label class="block text-sm font-medium mb-1">Nama Periode</label>
                <input type="text" name="nama" value="<?php echo e(old('nama', $periode->nama)); ?>"
                    class="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500" required>
                <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium mb-1">Tahun Akademik</label>
                <input type="text" name="tahun_akademik" value="<?php echo e(old('tahun_akademik', $periode->tahun_akademik)); ?>"
                    class="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500" required>
                <?php $__errorArgs = ['tahun_akademik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="grid grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm font-medium mb-1">Tanggal Mulai</label>
                    <input type="date" name="tanggal_mulai" value="<?php echo e(old('tanggal_mulai', $periode->tanggal_mulai->format('Y-m-d'))); ?>"
                        class="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500" required>
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Tanggal Selesai</label>
                    <input type="date" name="tanggal_selesai" value="<?php echo e(old('tanggal_selesai', $periode->tanggal_selesai->format('Y-m-d'))); ?>"
                        class="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500" required>
                </div>
            </div>
            <div class="mb-6">
                <label class="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" name="is_active" value="1" <?php echo e(old('is_active', $periode->is_active) ? 'checked' : ''); ?>>
                    <span class="text-sm font-medium">Aktif</span>
                </label>
            </div>
            <div class="flex gap-3">
                <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-blue-700">Update</button>
                <a href="<?php echo e(route('admin.periode.index')); ?>" class="border border-gray-300 text-gray-600 px-6 py-2 rounded-lg hover:bg-gray-50">Batal</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/admin/periods/edit.blade.php ENDPATH**/ ?>