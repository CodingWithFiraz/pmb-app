<?php $__env->startSection('title', 'Fakultas'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <h1 class="text-3xl font-bold text-gray-800">Fakultas</h1>
    <p class="text-gray-600 mt-1">Daftar fakultas yang menaungi seluruh program studi di <?php echo e($pengaturan['nama_singkat'] ?? 'PNM Jakarta'); ?>.</p>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 gap-5">
    <?php $__empty_1 = true; $__currentLoopData = $fakultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a href="<?php echo e(route('public.fakultas.detail', $f)); ?>"
            class="block bg-white shadow rounded-xl p-6 hover:shadow-lg hover:-translate-y-0.5 transition">
            <div class="flex items-start justify-between gap-3">
                <div>
                    <span class="text-xs font-mono font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded"><?php echo e($f->kode); ?></span>
                    <h2 class="font-bold text-lg mt-2 text-gray-800"><?php echo e($f->nama); ?></h2>
                    <?php if($f->deskripsi): ?>
                        <p class="text-gray-600 text-sm mt-2 leading-relaxed"><?php echo e($f->deskripsi); ?></p>
                    <?php endif; ?>
                </div>
                <div class="shrink-0 text-right">
                    <div class="text-2xl font-bold text-blue-700"><?php echo e($f->prodi_count); ?></div>
                    <div class="text-xs text-gray-500">Prodi</div>
                </div>
            </div>

            <div class="mt-4 text-sm text-blue-600 font-medium">Lihat program studi →</div>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-gray-500 col-span-2">Belum ada data fakultas.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/public/fakultas/index.blade.php ENDPATH**/ ?>