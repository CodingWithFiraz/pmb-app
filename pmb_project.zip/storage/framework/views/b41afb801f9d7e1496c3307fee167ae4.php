<?php $__env->startSection('title', $prodi->nama); ?>

<?php $__env->startSection('content'); ?>
<nav class="text-sm text-gray-500 mb-4">
    <a href="<?php echo e(route('home')); ?>" class="hover:text-blue-600">Beranda</a>
    <span class="mx-1">/</span>
    <a href="<?php echo e(route('public.fakultas')); ?>" class="hover:text-blue-600">Fakultas</a>
    <span class="mx-1">/</span>
    <a href="<?php echo e(route('public.fakultas.detail', $prodi->fakultas)); ?>" class="hover:text-blue-600"><?php echo e($prodi->fakultas->nama); ?></a>
    <span class="mx-1">/</span>
    <span class="text-gray-700"><?php echo e($prodi->nama); ?></span>
</nav>

<div class="bg-white shadow rounded-xl p-6 mb-6">
    <span class="text-xs font-mono font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded"><?php echo e($prodi->kode); ?></span>
    <h1 class="text-2xl md:text-3xl font-bold text-gray-800 mt-2"><?php echo e($prodi->nama); ?></h1>
    <div class="text-gray-600 mt-1"><?php echo e($prodi->jenjang); ?> · <?php echo e($prodi->fakultas->nama); ?></div>

    <?php if($prodi->deskripsi): ?>
        <p class="text-gray-600 mt-4 max-w-3xl leading-relaxed"><?php echo e($prodi->deskripsi); ?></p>
    <?php endif; ?>

    <div class="mt-4 flex flex-wrap gap-4 text-sm">
        <?php if($prodi->kuota): ?>
            <span class="bg-gray-100 text-gray-700 px-3 py-1 rounded">Kuota: <strong><?php echo e($prodi->kuota); ?></strong> mahasiswa</span>
        <?php endif; ?>
        <span class="bg-gray-100 text-gray-700 px-3 py-1 rounded">Jenjang: <strong><?php echo e($prodi->jenjang); ?></strong></span>
    </div>
</div>


<?php if($tarif->isNotEmpty()): ?>
    <div class="bg-white shadow rounded-xl p-6 mb-6">
        <h2 class="text-xl font-bold text-gray-800 mb-1">Biaya UKT</h2>
        <p class="text-sm text-gray-500 mb-4">
            <?php echo e($periode->nama); ?> — besaran UKT untuk <?php echo e($prodi->nama); ?> pada setiap jalur masuk dan golongan UKT.
        </p>

        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-50 text-gray-600">
                    <tr>
                        <th class="text-left px-4 py-3">Jalur</th>
                        <?php $__currentLoopData = $golongan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="px-4 py-3"><?php echo e($g->kode); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tarif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $namaJalur => $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-t">
                            <td class="px-4 py-3 font-medium"><?php echo e($namaJalur); ?></td>
                            <?php $__currentLoopData = $golongan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $row = $rows->firstWhere('golongan.kode', $g->kode); ?>
                                <td class="px-4 py-3">
                                    <?php echo e($row ? 'Rp '.number_format($row->nominal, 0, ',', '.') : '-'); ?>

                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <p class="text-xs text-gray-500 mt-3">Nominal dalam Rupiah (Rp) per tahun akademik.</p>
    </div>
<?php endif; ?>


<?php if($prodiLain->isNotEmpty()): ?>
    <div class="bg-white shadow rounded-xl p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Program Studi Lain di <?php echo e($prodi->fakultas->nama); ?></h2>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <?php $__currentLoopData = $prodiLain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('public.prodi', $p)); ?>" class="block border border-gray-200 rounded-lg p-4 hover:border-blue-400 hover:bg-blue-50/40">
                    <div class="font-semibold text-gray-800"><?php echo e($p->nama); ?></div>
                    <div class="text-sm text-gray-500"><?php echo e($p->jenjang); ?> · <?php echo e($p->kode); ?></div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/public/prodi/show.blade.php ENDPATH**/ ?>