<?php $__env->startSection('title', $dokumen->exists ? 'Edit Dokumen' : 'Tambah Dokumen'); ?>

<?php $__env->startSection('content'); ?>
<?php $isEdit = $dokumen->exists; ?>

<div class="max-w-lg mx-auto">
    <h1 class="text-2xl font-bold mb-6"><?php echo e($isEdit ? 'Edit Dokumen' : 'Tambah Dokumen'); ?></h1>

    <div class="bg-white shadow rounded-xl p-6">
        <form method="POST" action="<?php echo e($isEdit ? route('admin.dokumen.update', $dokumen) : route('admin.dokumen.store')); ?>">
            <?php echo csrf_field(); ?>
            <?php if($isEdit): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

            <div class="grid grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm font-medium mb-1">Kode <span class="text-red-500">*</span></label>
                    <input type="text" name="kode" value="<?php echo e(old('kode', $dokumen->kode)); ?>"
                        class="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 <?php $__errorArgs = ['kode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="cth: KTP" required>
                    <?php $__errorArgs = ['kode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label class="block text-sm font-medium mb-1">Tipe Berkas <span class="text-red-500">*</span></label>
                    <select name="tipe_file" class="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 <?php $__errorArgs = ['tipe_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="pdf" <?php echo e(old('tipe_file', $dokumen->tipe_file ?? 'pdf') === 'pdf' ? 'selected' : ''); ?>>PDF</option>
                        <option value="jpg" <?php echo e(old('tipe_file', $dokumen->tipe_file) === 'jpg' ? 'selected' : ''); ?>>JPG</option>
                    </select>
                    <?php $__errorArgs = ['tipe_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium mb-1">Nama Dokumen <span class="text-red-500">*</span></label>
                <input type="text" name="nama" value="<?php echo e(old('nama', $dokumen->nama)); ?>"
                    class="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium mb-1">Ukuran Maksimum (KB) <span class="text-red-500">*</span></label>
                <input type="number" name="max_size" value="<?php echo e(old('max_size', $dokumen->max_size ?? 2048)); ?>" min="100" max="10240"
                    class="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 <?php $__errorArgs = ['max_size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                <?php $__errorArgs = ['max_size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-6">
                <label class="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" name="is_wajib" value="1" <?php echo e(old('is_wajib', $dokumen->is_wajib) ? 'checked' : ''); ?>>
                    <span class="text-sm font-medium">Dokumen wajib diunggah</span>
                </label>
            </div>

            <div class="flex gap-3">
                <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-blue-700">
                    <?php echo e($isEdit ? 'Update' : 'Simpan'); ?>

                </button>
                <a href="<?php echo e(route('admin.dokumen.index')); ?>" class="border border-gray-300 text-gray-600 px-6 py-2 rounded-lg hover:bg-gray-50">Batal</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/admin/dokumen/form.blade.php ENDPATH**/ ?>