<?php $__env->startSection('title', 'Tarif UKT'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold">Matrix Tarif UKT</h1>
    <p class="text-sm text-gray-600">Nominal UKT per jalur, program studi, dan golongan.</p>
</div>

<form method="GET" class="bg-white shadow rounded-xl p-4 mb-6 flex flex-wrap gap-3 items-end">
    <div>
        <label class="block text-sm font-medium mb-1">Periode</label>
        <select name="periode_id" class="border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500">
            <?php $__currentLoopData = $periodeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($p->id); ?>" <?php echo e($periode && $periode->id === $p->id ? 'selected' : ''); ?>>
                    <?php echo e($p->nama); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700">Tampilkan</button>
</form>

<?php if($periode): ?>
    <form method="POST" action="<?php echo e(route('admin.tarif-ukt.update')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="periode_id" value="<?php echo e($periode->id); ?>">

        <div class="space-y-6">
            <?php $__empty_1 = true; $__currentLoopData = $jalur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="bg-white shadow rounded-xl p-5">
                    <h2 class="font-bold mb-3">
                        <?php echo e($j->nama); ?> <span class="text-xs font-mono text-gray-500"><?php echo e($j->kode); ?></span>
                    </h2>

                    <div class="overflow-x-auto">
                        <table class="w-full text-sm">
                            <thead class="bg-gray-50 text-gray-600">
                                <tr>
                                    <th class="text-left px-3 py-2">Program Studi</th>
                                    <?php $__currentLoopData = $golongan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="px-3 py-2"><?php echo e($g->kode); ?></th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_2 = true; $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                    <tr class="border-t">
                                        <td class="px-3 py-2">
                                            <?php echo e($p->nama); ?>

                                            <span class="text-xs text-gray-400"><?php echo e($p->kode); ?></span>
                                        </td>

                                        <?php $__currentLoopData = $golongan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $key = $j->id.'-'.$p->id.'-'.$g->id;
                                                $nominal = $tarif[$key]->nominal ?? null;
                                            ?>
                                            <td class="px-3 py-1">
                                                <input type="number" name="tarif[<?php echo e($key); ?>]" min="0" step="1000"
                                                    value="<?php echo e(old('tarif.'.$key, $nominal)); ?>"
                                                    class="w-full border rounded px-2 py-1 text-right text-sm focus:ring-2 focus:ring-blue-500">
                                            </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                    <tr><td colspan="10" class="px-3 py-4 text-gray-500">Belum ada program studi.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-gray-500">Belum ada jalur masuk.</p>
            <?php endif; ?>
        </div>

        <div class="mt-6 flex justify-end">
            <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-blue-700">
                Simpan Tarif UKT
            </button>
        </div>
    </form>
<?php else: ?>
    <p class="text-gray-500">Belum ada periode pendaftaran.</p>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/admin/tarif/index.blade.php ENDPATH**/ ?>