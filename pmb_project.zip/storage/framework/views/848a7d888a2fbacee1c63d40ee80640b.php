<div class="space-y-5">
    <div>
        <label for="asal_sekolah" class="<?php echo e($labelClass); ?>">Nama Sekolah Asal <span class="text-red-500">*</span></label>
        <input type="text" name="asal_sekolah" id="asal_sekolah"
            value="<?php echo e(old('asal_sekolah', $profile?->asal_sekolah)); ?>" class="<?php echo e($inputClass); ?>"
            placeholder="Contoh: SMA Negeri 1 Jakarta">
        <?php $__errorArgs = ['asal_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="<?php echo e($errorClass); ?>"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="sm:w-1/2">
        <label for="tahun_lulus" class="<?php echo e($labelClass); ?>">Tahun Lulus <span class="text-red-500">*</span></label>
        <input type="number" name="tahun_lulus" id="tahun_lulus" min="1950" max="<?php echo e(now()->year); ?>"
            value="<?php echo e(old('tahun_lulus', $profile?->tahun_lulus)); ?>" class="<?php echo e($inputClass); ?>"
            placeholder="<?php echo e(now()->year); ?>">
        <?php $__errorArgs = ['tahun_lulus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="<?php echo e($errorClass); ?>"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/pendaftar/profil/steps/step-3.blade.php ENDPATH**/ ?>