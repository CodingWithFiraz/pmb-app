<?php $__env->startSection('title', 'Biaya Pendaftaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold">Biaya Pendaftaran</h1>
    <a href="<?php echo e(route('admin.biaya-pendaftaran.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700">+ Tambah Biaya</a>
</div>

<form method="GET" class="bg-white shadow rounded-xl p-4 mb-6 flex flex-wrap gap-3 items-end">
    <div>
        <label class="block text-sm font-medium mb-1">Periode</label>
        <select name="periode_id" class="border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500">
            <option value="">Semua Periode</option>
            <?php $__currentLoopData = $periodeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($p->id); ?>" <?php echo e((int) request('periode_id') === $p->id ? 'selected' : ''); ?>>
                    <?php echo e($p->nama); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700">Filter</button>
</form>

<div class="bg-white shadow rounded-xl overflow-hidden">
    <table class="w-full text-sm">
        <thead class="bg-gray-50 text-gray-600">
            <tr>
                <th class="text-left px-4 py-3">Periode</th>
                <th class="text-left px-4 py-3">Jalur Masuk</th>
                <th class="text-left px-4 py-3">Nominal</th>
                <th class="px-4 py-3"></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $biaya; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-t">
                    <td class="px-4 py-3"><?php echo e($b->periode->nama); ?></td>
                    <td class="px-4 py-3 font-medium"><?php echo e($b->jalur->nama); ?></td>
                    <td class="px-4 py-3">
                        <?php if($b->nominal === null): ?>
                            <span class="text-green-600 font-semibold">Gratis</span>
                        <?php else: ?>
                            <span class="font-semibold">Rp <?php echo e(number_format($b->nominal, 0, ',', '.')); ?></span>
                        <?php endif; ?>
                    </td>
                    <td class="px-4 py-3">
                        <div class="flex items-center gap-3">
                            <a href="<?php echo e(route('admin.biaya-pendaftaran.edit', $b)); ?>" class="text-blue-600 hover:underline text-xs">Edit</a>

                            <form method="POST" action="<?php echo e(route('admin.biaya-pendaftaran.destroy', $b)); ?>"
                                onsubmit="return confirm('Hapus biaya pendaftaran ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:underline text-xs">Hapus</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4" class="text-center py-8 text-gray-500">Belum ada data biaya pendaftaran.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-4"><?php echo e($biaya->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/admin/biaya/index.blade.php ENDPATH**/ ?>