<?php $__env->startSection('title', 'Tentang Kampus'); ?>

<?php $__env->startSection('content'); ?>

<div class="bg-gradient-to-r from-blue-700 to-blue-900 text-white rounded-2xl p-8 md:p-12 mb-8">
    <h1 class="text-3xl md:text-4xl font-bold mb-2">Tentang <?php echo e($pengaturan['nama_singkat'] ?? 'Kampus'); ?></h1>
    <p class="text-blue-100 max-w-3xl leading-relaxed"><?php echo e($pengaturan['nama_kampus'] ?? ''); ?></p>
</div>


<?php if(! empty($pengaturan['sejarah'])): ?>
    <div class="bg-white shadow rounded-xl p-6 mb-6">
        <h2 class="text-xl font-bold text-gray-800 mb-3">Sejarah</h2>
        <p class="text-gray-600 leading-relaxed"><?php echo e($pengaturan['sejarah']); ?></p>
    </div>
<?php endif; ?>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
    
    <div class="bg-white shadow rounded-xl p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-3">Visi</h2>
        <p class="text-gray-600 leading-relaxed"><?php echo e($pengaturan['visi'] ?? '-'); ?></p>
    </div>

    
    <div class="bg-white shadow rounded-xl p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-3">Misi</h2>
        <?php if(! empty($pengaturan['misi'])): ?>
            <ul class="space-y-2 text-gray-600">
                <?php $__currentLoopData = preg_split('/\R/', $pengaturan['misi']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(trim($poin) !== ''): ?>
                        <li class="flex gap-2">
                            <span class="text-blue-600 font-bold shrink-0">•</span>
                            <span class="leading-relaxed"><?php echo e(trim($poin)); ?></span>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <p class="text-gray-600">-</p>
        <?php endif; ?>
    </div>
</div>


<?php if(! empty($pengaturan['sambutan'])): ?>
    <div class="bg-white shadow rounded-xl p-6 mb-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Sambutan</h2>

        <div class="flex flex-col md:flex-row gap-6">
            <div class="shrink-0">
                <div class="w-20 h-20 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center text-2xl font-bold">
                    <?php echo e(mb_substr($pengaturan['sambutan_nama'] ?? 'P', 0, 1)); ?>

                </div>
            </div>
            <div>
                <p class="text-gray-600 leading-relaxed italic"><?php echo e($pengaturan['sambutan']); ?></p>
                <div class="mt-4">
                    <div class="font-semibold text-gray-800"><?php echo e($pengaturan['sambutan_nama'] ?? '-'); ?></div>
                    <div class="text-sm text-gray-500"><?php echo e($pengaturan['sambutan_jabatan'] ?? ''); ?></div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>


<div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
    <div class="bg-white shadow rounded-xl p-5 text-center">
        <div class="text-3xl font-bold text-blue-700"><?php echo e($fakultas->count()); ?></div>
        <div class="text-sm text-gray-600 mt-1">Fakultas</div>
    </div>
    <div class="bg-white shadow rounded-xl p-5 text-center">
        <div class="text-3xl font-bold text-blue-700"><?php echo e($prodi); ?></div>
        <div class="text-sm text-gray-600 mt-1">Program Studi</div>
    </div>
    <div class="bg-white shadow rounded-xl p-5 text-center">
        <div class="text-3xl font-bold text-blue-700"><?php echo e($fakultas->sum('prodi_count')); ?></div>
        <div class="text-sm text-gray-600 mt-1">Program Studi Terdaftar</div>
    </div>
    <div class="bg-white shadow rounded-xl p-5 text-center">
        <div class="text-3xl font-bold text-blue-700">S1</div>
        <div class="text-sm text-gray-600 mt-1">Jenjang offerings</div>
    </div>
</div>


<div class="bg-white shadow rounded-xl p-6">
    <h2 class="text-xl font-bold text-gray-800 mb-4">Fakultas</h2>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <?php $__currentLoopData = $fakultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('public.fakultas.detail', $f)); ?>"
                class="block border border-gray-200 rounded-lg p-4 hover:border-blue-400 hover:bg-blue-50/40 transition">
                <div class="font-semibold text-gray-800"><?php echo e($f->nama); ?></div>
                <div class="text-sm text-gray-500 mt-1"><?php echo e($f->prodi_count); ?> program studi</div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/public/tentang-kampus.blade.php ENDPATH**/ ?>