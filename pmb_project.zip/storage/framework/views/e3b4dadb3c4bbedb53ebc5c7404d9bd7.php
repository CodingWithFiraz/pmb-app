<?php $__env->startSection('title', 'Pengaturan Situs'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto">
    <h1 class="text-2xl font-bold mb-2">Pengaturan Situs</h1>
    <p class="text-sm text-gray-600 mb-6">
        Nilai pengaturan ini dipakai pada halaman publik (alamat, kontak, peta, visi, misi, dan sambutan).
        Mengosongkan nilai berarti pengaturan tersebut tidak dipakai.
    </p>

    <div class="bg-white shadow rounded-xl p-6">
        <form method="POST" action="<?php echo e(route('admin.pengaturan.update')); ?>">
            <?php echo csrf_field(); ?>

            <div class="space-y-5">
                <?php $__empty_1 = true; $__currentLoopData = $pengaturan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div>
                        <label for="setting-<?php echo e($p->key); ?>" class="block text-sm font-medium mb-1">
                            <span class="font-mono text-xs text-gray-500"><?php echo e($p->key); ?></span>
                        </label>
                        <textarea name="settings[<?php echo e($p->key); ?>]" id="setting-<?php echo e($p->key); ?>" rows="3"
                            class="w-full border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500"><?php echo e(old('settings.'.$p->key, $p->value)); ?></textarea>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500 text-sm">Belum ada pengaturan tersimpan.</p>
                <?php endif; ?>
            </div>

            <div class="mt-8 border-t border-gray-100 pt-5">
                <h2 class="font-semibold text-gray-700 mb-3">Tambah Pengaturan Baru</h2>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label for="key_baru" class="block text-sm font-medium mb-1">Key</label>
                        <input type="text" name="key_baru" id="key_baru" value="<?php echo e(old('key_baru')); ?>"
                            class="w-full border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 <?php $__errorArgs = ['key_baru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            placeholder="contoh: nama_kampus">
                        <?php $__errorArgs = ['key_baru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label for="value_baru" class="block text-sm font-medium mb-1">Nilai</label>
                        <input type="text" name="value_baru" id="value_baru" value="<?php echo e(old('value_baru')); ?>"
                            class="w-full border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500">
                    </div>
                </div>
            </div>

            <div class="mt-6">
                <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-blue-700">
                    Simpan Pengaturan
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/admin/pengaturan/index.blade.php ENDPATH**/ ?>