<?php $__env->startSection('title', $fakultas->nama); ?>

<?php $__env->startSection('content'); ?>
<nav class="text-sm text-gray-500 mb-4">
    <a href="<?php echo e(route('home')); ?>" class="hover:text-blue-600">Beranda</a>
    <span class="mx-1">/</span>
    <a href="<?php echo e(route('public.fakultas')); ?>" class="hover:text-blue-600">Fakultas</a>
    <span class="mx-1">/</span>
    <span class="text-gray-700"><?php echo e($fakultas->nama); ?></span>
</nav>

<div class="bg-white shadow rounded-xl p-6 mb-6">
    <div class="flex items-start justify-between gap-4 flex-wrap">
        <div>
            <span class="text-xs font-mono font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded"><?php echo e($fakultas->kode); ?></span>
            <h1 class="text-2xl md:text-3xl font-bold text-gray-800 mt-2"><?php echo e($fakultas->nama); ?></h1>
            <?php if($fakultas->deskripsi): ?>
                <p class="text-gray-600 mt-2 max-w-3xl leading-relaxed"><?php echo e($fakultas->deskripsi); ?></p>
            <?php endif; ?>
        </div>
        <div class="text-right">
            <div class="text-3xl font-bold text-blue-700"><?php echo e($fakultas->prodi->count()); ?></div>
            <div class="text-xs text-gray-500">Program Studi</div>
        </div>
    </div>
</div>

<h2 class="text-xl font-bold text-gray-800 mb-4">Program Studi</h2>

<div class="grid grid-cols-1 md:grid-cols-2 gap-5">
    <?php $__empty_1 = true; $__currentLoopData = $fakultas->prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a href="<?php echo e(route('public.prodi', $prodi)); ?>"
            class="block bg-white shadow rounded-xl p-5 hover:shadow-lg transition">
            <div class="flex justify-between items-start gap-3">
                <div>
                    <span class="text-xs font-mono font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded"><?php echo e($prodi->kode); ?></span>
                    <h3 class="font-bold text-lg mt-2 text-gray-800"><?php echo e($prodi->nama); ?></h3>
                    <div class="text-sm text-gray-500"><?php echo e($prodi->jenjang); ?></div>
                    <?php if($prodi->deskripsi): ?>
                        <p class="text-gray-600 text-sm mt-2 leading-relaxed"><?php echo e($prodi->deskripsi); ?></p>
                    <?php endif; ?>
                </div>
                <?php if($prodi->kuota): ?>
                    <div class="shrink-0 text-right">
                        <div class="text-gray-400 text-xs">Kuota</div>
                        <div class="font-bold text-blue-700"><?php echo e($prodi->kuota); ?></div>
                    </div>
                <?php endif; ?>
            </div>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-gray-500 col-span-2">Belum ada program studi pada fakultas ini.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/public/fakultas/show.blade.php ENDPATH**/ ?>