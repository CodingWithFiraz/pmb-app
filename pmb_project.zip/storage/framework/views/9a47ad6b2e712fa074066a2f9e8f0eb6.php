<div class="space-y-5">
    <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
        <div>
            <label for="nama_ortu" class="<?php echo e($labelClass); ?>">Nama Orang Tua / Wali <span class="text-red-500">*</span></label>
            <input type="text" name="nama_ortu" id="nama_ortu"
                value="<?php echo e(old('nama_ortu', $profile?->nama_ortu)); ?>" class="<?php echo e($inputClass); ?>">
            <?php $__errorArgs = ['nama_ortu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="<?php echo e($errorClass); ?>"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label for="pekerjaan_ortu" class="<?php echo e($labelClass); ?>">Pekerjaan Orang Tua / Wali <span class="text-red-500">*</span></label>
            <input type="text" name="pekerjaan_ortu" id="pekerjaan_ortu"
                value="<?php echo e(old('pekerjaan_ortu', $profile?->pekerjaan_ortu)); ?>" class="<?php echo e($inputClass); ?>">
            <?php $__errorArgs = ['pekerjaan_ortu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="<?php echo e($errorClass); ?>"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="sm:w-1/2">
        <label for="penghasilan_ortu" class="<?php echo e($labelClass); ?>">Penghasilan Orang Tua / Bulan (Rp) <span class="text-red-500">*</span></label>
        <input type="number" name="penghasilan_ortu" id="penghasilan_ortu" min="0" step="100000"
            value="<?php echo e(old('penghasilan_ortu', $profile?->penghasilan_ortu)); ?>" class="<?php echo e($inputClass); ?>"
            placeholder="Contoh: 4500000">
        <p class="mt-1 text-xs text-gray-500">Masukkan angka tanpa titik atau koma.</p>
        <?php $__errorArgs = ['penghasilan_ortu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="<?php echo e($errorClass); ?>"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div>
        <span class="<?php echo e($labelClass); ?>">Golongan UKT <span class="text-red-500">*</span></span>
        <p class="mt-1 text-xs text-gray-500">
            Pilih golongan yang paling sesuai. Besaran UKT juga bergantung pada jalur masuk dan program studi.
        </p>

        <div class="mt-3 space-y-2">
            <?php $__currentLoopData = $golongan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="flex cursor-pointer items-start gap-3 rounded-lg border border-gray-200 px-4 py-3 hover:border-blue-400 hover:bg-blue-50/40">
                    <input type="radio" name="golongan_id" value="<?php echo e($g->id); ?>" class="mt-1"
                        <?php if((int) old('golongan_id', $profile?->golongan_id) === $g->id): echo 'checked'; endif; ?>>
                    <span>
                        <span class="block text-sm font-medium text-gray-800"><?php echo e($g->nama); ?></span>
                        <?php if($g->deskripsi): ?>
                            <span class="block text-xs text-gray-500"><?php echo e($g->deskripsi); ?></span>
                        <?php endif; ?>
                    </span>
                </label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php $__errorArgs = ['golongan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="<?php echo e($errorClass); ?>"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/pendaftar/profil/steps/step-4.blade.php ENDPATH**/ ?>