<?php $__env->startSection('title', 'Pilihan Jalur & Program Studi'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto">

    <?php if($terkunci): ?>
        <div class="mb-5 rounded-lg border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-800">
            Pilihan jalur dan program studi <strong>dikunci</strong> karena status pendaftaran sudah
            <strong><?php echo e($pendaftaran->statusLabel()); ?></strong>. Hubungi panitia PMB jika perlu perubahan.
        </div>
    <?php endif; ?>

    <div class="bg-white shadow rounded-xl p-6">
        <div class="flex flex-wrap items-start justify-between gap-3">
            <div>
                <h2 class="text-lg font-bold text-gray-800">Pilihan Pendaftaran</h2>
                <p class="mt-1 text-sm text-gray-600">
                    Periode <?php echo e($periode->nama); ?> (TA <?php echo e($periode->tahun_akademik); ?>).
                </p>
            </div>

            <?php if($pendaftaran): ?>
                <span class="rounded-full px-3 py-1 text-xs font-semibold <?php echo e($pendaftaran->isDraft() ? 'bg-blue-100 text-blue-700' : 'bg-amber-100 text-amber-700'); ?>">
                    <?php echo e($pendaftaran->statusLabel()); ?>

                </span>
            <?php else: ?>
                <span class="rounded-full bg-gray-100 px-3 py-1 text-xs font-semibold text-gray-600">
                    Belum disimpan
                </span>
            <?php endif; ?>
        </div>

        <form id="form-pilihan" method="POST" action="<?php echo e(route('pendaftar.pilihan.update')); ?>" class="mt-6">
            <?php echo csrf_field(); ?>

            <fieldset <?php if($terkunci): echo 'disabled'; endif; ?> class="space-y-5">
                
                <div>
                    <label for="jalur_id" class="block text-sm font-medium text-gray-700">
                        Jalur Masuk <span class="text-red-500">*</span>
                    </label>
                    <select name="jalur_id" id="jalur_id"
                        class="mt-1 block w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500">
                        <option value="">-- Pilih jalur masuk --</option>
                        <?php $__currentLoopData = $jalur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($j->id); ?>" <?php if($selected['jalur_id'] === $j->id): echo 'selected'; endif; ?>>
                                <?php echo e($j->nama); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['jalur_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div>
                    <label for="prodi_1_id" class="block text-sm font-medium text-gray-700">
                        Program Studi Pilihan 1 <span class="text-red-500">*</span>
                    </label>
                    <select name="prodi_1_id" id="prodi_1_id"
                        class="mt-1 block w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500">
                        <option value="">-- Pilih program studi --</option>
                        <?php $__currentLoopData = $prodi->groupBy(fn ($p) => $p->fakultas?->nama ?? 'Lainnya'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $namaFakultas => $daftar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <optgroup label="<?php echo e($namaFakultas); ?>">
                                <?php $__currentLoopData = $daftar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($p->id); ?>" <?php if($selected['prodi_1_id'] === $p->id): echo 'selected'; endif; ?>>
                                        <?php echo e($p->nama); ?> (<?php echo e($p->jenjang); ?>)
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </optgroup>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['prodi_1_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div>
                    <label for="prodi_2_id" class="block text-sm font-medium text-gray-700">
                        Program Studi Pilihan 2 <span class="text-gray-400">(opsional)</span>
                    </label>
                    <select name="prodi_2_id" id="prodi_2_id"
                        class="mt-1 block w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500">
                        <option value="">-- Tidak memilih pilihan kedua --</option>
                        <?php $__currentLoopData = $prodi->groupBy(fn ($p) => $p->fakultas?->nama ?? 'Lainnya'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $namaFakultas => $daftar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <optgroup label="<?php echo e($namaFakultas); ?>">
                                <?php $__currentLoopData = $daftar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($p->id); ?>" <?php if($selected['prodi_2_id'] === $p->id): echo 'selected'; endif; ?>>
                                        <?php echo e($p->nama); ?> (<?php echo e($p->jenjang); ?>)
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </optgroup>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <p class="mt-1 text-xs text-gray-500">Boleh sama dengan pilihan pertama.</p>
                    <?php $__errorArgs = ['prodi_2_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div>
                    <label for="golongan_id" class="block text-sm font-medium text-gray-700">
                        Golongan UKT <span class="text-red-500">*</span>
                    </label>
                    <select name="golongan_id" id="golongan_id"
                        class="mt-1 block w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500">
                        <?php $__currentLoopData = $golongan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($g->id); ?>" <?php if($selected['golongan_id'] === $g->id): echo 'selected'; endif; ?>>
                                <?php echo e($g->nama); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <p class="mt-1 text-xs text-gray-500">
                        Golongan awal berasal dari profil. Perubahan di sini akan memperbarui data profil.
                    </p>
                    <?php $__errorArgs = ['golongan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </fieldset>

            
            <div class="mt-6 rounded-xl border border-blue-200 bg-blue-50 p-5">
                <div class="flex flex-wrap items-end justify-between gap-3">
                    <div>
                        <div class="text-sm text-blue-700">Perkiraan UKT per tahun</div>
                        <div id="ukt-preview" class="mt-1 text-2xl font-bold text-blue-900">
                            <?php echo e($ukt !== null ? 'Rp '.number_format($ukt, 0, ',', '.') : 'Belum tersedia'); ?>

                        </div>
                    </div>
                    <div class="text-right text-sm text-blue-700">
                        Biaya pendaftaran:
                        <span id="biaya-preview" class="font-semibold text-blue-900">-</span>
                    </div>
                </div>
                <p class="mt-2 text-xs text-blue-700">
                    Dihitung dari jalur masuk, program studi pilihan pertama, dan golongan UKT.
                </p>
            </div>

            <?php if(! $terkunci): ?>
                <div class="mt-6 flex flex-wrap items-center gap-3 border-t border-gray-100 pt-5">
                    <button type="submit"
                        class="rounded-lg bg-blue-600 px-5 py-2 text-sm font-semibold text-white hover:bg-blue-700">
                        Simpan Pilihan
                    </button>
                    <a href="<?php echo e(route('pendaftar.dashboard')); ?>" class="text-sm text-gray-500 hover:underline">
                        Kembali ke dashboard
                    </a>
                </div>
            <?php endif; ?>
        </form>
    </div>
</div>

<?php if(! $terkunci): ?>
    <script>
        (function () {
            const uktTarget = document.getElementById('ukt-preview');
            const biayaTarget = document.getElementById('biaya-preview');
            const endpoint = <?php echo json_encode(route('pendaftar.pilihan.preview'), 15, 512) ?>;
            const fields = ['jalur_id', 'prodi_1_id', 'golongan_id'];

            if (! uktTarget || ! endpoint) {
                return;
            }

            async function refresh() {
                const params = new URLSearchParams();

                fields.forEach(function (id) {
                    const el = document.getElementById(id);
                    if (el && el.value) {
                        params.set(id, el.value);
                    }
                });

                uktTarget.textContent = 'Memuat...';

                try {
                    const response = await fetch(endpoint + '?' + params.toString(), {
                        headers: { 'Accept': 'application/json' },
                    });

                    if (! response.ok) {
                        throw new Error('Gagal memuat preview');
                    }

                    const data = await response.json();
                    uktTarget.textContent = data.formatted || 'Belum tersedia';

                    if (biayaTarget) {
                        biayaTarget.textContent = data.biaya_label || '-';
                    }
                } catch (error) {
                    uktTarget.textContent = 'Belum tersedia';
                }
            }

            fields.forEach(function (id) {
                const el = document.getElementById(id);
                if (el) {
                    el.addEventListener('change', refresh);
                }
            });

            refresh();
        })();
    </script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pendaftar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/pendaftar/pilihan.blade.php ENDPATH**/ ?>