<?php $__env->startSection('title', 'Informasi PMB'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <h1 class="text-3xl font-bold text-gray-800">Informasi PMB</h1>
    <p class="text-gray-600 mt-1">Jalur masuk, biaya pendaftaran, dan tarif Uang Kuliah Tunggal (UKT).</p>
</div>

<?php if(! $periode): ?>
    <div class="bg-yellow-50 border border-yellow-300 text-yellow-800 rounded-xl p-6">
        Saat ini belum ada periode pendaftaran yang aktif. Silakan cek halaman berita untuk informasi terbaru.
    </div>
<?php else: ?>
    
    <div class="bg-blue-50 border border-blue-200 rounded-xl p-6 mb-6">
        <h2 class="text-lg font-bold text-blue-900 mb-2">Jadwal Pendaftaran</h2>
        <div class="text-blue-800"><?php echo e($periode->nama); ?></div>
        <div class="text-sm text-blue-700 mt-1">Tahun Akademik <?php echo e($periode->tahun_akademik); ?></div>
        <div class="text-sm text-blue-700 mt-1">
            <?php echo e($periode->tanggal_mulai->translatedFormat('d F Y')); ?> — <?php echo e($periode->tanggal_selesai->translatedFormat('d F Y')); ?>

        </div>
    </div>

    
    <div class="bg-white shadow rounded-xl p-6 mb-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Jalur Masuk</h2>

        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-50 text-gray-600">
                    <tr>
                        <th class="text-left px-4 py-3">Kode</th>
                        <th class="text-left px-4 py-3">Jalur</th>
                        <th class="text-left px-4 py-3">Deskripsi</th>
                        <th class="px-4 py-3">Biaya Pendaftaran</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $jalur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $b = $biaya->get($j->nama); ?>
                        <tr class="border-t align-top">
                            <td class="px-4 py-3">
                                <span class="text-xs font-mono font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded"><?php echo e($j->kode); ?></span>
                            </td>
                            <td class="px-4 py-3 font-medium"><?php echo e($j->nama); ?></td>
                            <td class="px-4 py-3 text-gray-600"><?php echo e($j->deskripsi); ?></td>
                            <td class="px-4 py-3 font-semibold">
                                <?php if($b && $b->nominal !== null): ?>
                                    Rp <?php echo e(number_format($b->nominal, 0, ',', '.')); ?>

                                <?php else: ?>
                                    <span class="text-green-600">Gratis</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div class="bg-white shadow rounded-xl p-6 mb-6">
        <h2 class="text-xl font-bold text-gray-800 mb-1">Biaya UKT</h2>
        <p class="text-sm text-gray-500 mb-4">
            Besaran UKT per tahun akademik untuk <?php echo e($periode->nama); ?>, dikelompokkan per jalur masuk, program studi, dan golongan UKT.
        </p>

        <?php $__currentLoopData = $tarif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $namaJalur => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($data['prodi']->isNotEmpty()): ?>
                <div class="mb-6 last:mb-0">
                    <h3 class="font-semibold text-gray-700 mb-2"><?php echo e($namaJalur); ?></h3>

                    <div class="overflow-x-auto">
                        <table class="w-full text-sm">
                            <thead class="bg-gray-50 text-gray-600">
                                <tr>
                                    <th class="text-left px-4 py-2">Program Studi</th>
                                    <?php $__currentLoopData = $golongan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="px-4 py-2"><?php echo e($g->kode); ?></th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data['prodi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="border-t">
                                        <td class="px-4 py-2 font-medium"><?php echo e($p->nama); ?></td>
                                        <?php $__currentLoopData = $golongan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $row = $data['tarif'][$p->id][$g->id] ?? null; ?>
                                            <td class="px-4 py-2"><?php echo e($row ? 'Rp '.number_format($row->nominal, 0, ',', '.') : '-'); ?></td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <p class="text-xs text-gray-500 mt-4">
            Seluruh nominal dalam Rupiah (Rp) per tahun akademik.
        </p>
    </div>

    
    <div class="bg-white shadow rounded-xl p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Program Studi</h2>

        <?php $__currentLoopData = $prodiPerFakultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $namaFakultas => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-4 last:mb-0">
                <h3 class="font-semibold text-gray-700 mb-2"><?php echo e($namaFakultas); ?></h3>
                <div class="flex flex-wrap gap-2">
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('public.prodi', $p)); ?>"
                            class="inline-block border border-gray-200 rounded-lg px-3 py-2 text-sm hover:border-blue-400 hover:bg-blue-50/40">
                            <?php echo e($p->nama); ?> <span class="text-gray-400 text-xs"><?php echo e($p->kode); ?></span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/public/informasi-pmb.blade.php ENDPATH**/ ?>