<?php $__env->startSection('title', 'Program Studi'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-bold mb-6">Program Studi</h1>

<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
    <?php $__empty_1 = true; $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="bg-white shadow rounded-xl p-5">
            <div class="flex justify-between items-start">
                <div>
                    <span class="text-xs font-mono font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded"><?php echo e($program->kode); ?></span>
                    <h3 class="font-bold text-lg mt-1"><?php echo e($program->nama); ?></h3>
                    <div class="text-gray-500 text-sm">
                        <?php echo e($program->jenjang); ?> · <?php echo e($program->fakultas->nama); ?>

                    </div>
                    <?php if($program->deskripsi): ?>
                        <p class="text-gray-600 text-sm mt-2"><?php echo e($program->deskripsi); ?></p>
                    <?php endif; ?>
                </div>
                <?php if($program->kuota): ?>
                    <div class="text-right text-sm">
                        <div class="text-gray-400">Kuota</div>
                        <div class="font-bold text-blue-700"><?php echo e($program->kuota); ?></div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-gray-500 col-span-2">Belum ada program studi.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/public/programs.blade.php ENDPATH**/ ?>