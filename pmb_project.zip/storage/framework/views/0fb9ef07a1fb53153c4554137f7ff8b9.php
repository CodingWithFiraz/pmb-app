<div class="space-y-5">
    <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
        <div>
            <label for="nik" class="<?php echo e($labelClass); ?>">NIK <span class="text-red-500">*</span></label>
            <input type="text" name="nik" id="nik" inputmode="numeric" maxlength="16"
                value="<?php echo e(old('nik', $profile?->nik)); ?>" class="<?php echo e($inputClass); ?>" placeholder="16 digit NIK">
            <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="<?php echo e($errorClass); ?>"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label for="nisn" class="<?php echo e($labelClass); ?>">NISN <span class="text-red-500">*</span></label>
            <input type="text" name="nisn" id="nisn" inputmode="numeric" maxlength="10"
                value="<?php echo e(old('nisn', $profile?->nisn)); ?>" class="<?php echo e($inputClass); ?>" placeholder="10 digit NISN">
            <?php $__errorArgs = ['nisn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="<?php echo e($errorClass); ?>"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
        <div>
            <label for="tempat_lahir" class="<?php echo e($labelClass); ?>">Tempat Lahir <span class="text-red-500">*</span></label>
            <input type="text" name="tempat_lahir" id="tempat_lahir"
                value="<?php echo e(old('tempat_lahir', $profile?->tempat_lahir)); ?>" class="<?php echo e($inputClass); ?>">
            <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="<?php echo e($errorClass); ?>"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label for="tanggal_lahir" class="<?php echo e($labelClass); ?>">Tanggal Lahir <span class="text-red-500">*</span></label>
            <input type="date" name="tanggal_lahir" id="tanggal_lahir"
                value="<?php echo e(old('tanggal_lahir', $profile?->tanggal_lahir?->format('Y-m-d'))); ?>" class="<?php echo e($inputClass); ?>">
            <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="<?php echo e($errorClass); ?>"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div>
        <span class="<?php echo e($labelClass); ?>">Jenis Kelamin <span class="text-red-500">*</span></span>

        <div class="mt-2 flex gap-6">
            <label class="flex items-center gap-2 text-sm text-gray-700">
                <input type="radio" name="jenis_kelamin" value="L"
                    <?php if(old('jenis_kelamin', $profile?->jenis_kelamin) === 'L'): echo 'checked'; endif; ?>>
                Laki-laki
            </label>
            <label class="flex items-center gap-2 text-sm text-gray-700">
                <input type="radio" name="jenis_kelamin" value="P"
                    <?php if(old('jenis_kelamin', $profile?->jenis_kelamin) === 'P'): echo 'checked'; endif; ?>>
                Perempuan
            </label>
        </div>

        <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="<?php echo e($errorClass); ?>"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/pendaftar/profil/steps/step-1.blade.php ENDPATH**/ ?>