<?php $__env->startSection('title', 'Profil Pendaftar'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto">

    
    <div class="bg-white shadow rounded-xl p-6 mb-6">
        <div class="flex flex-wrap items-center justify-between gap-3">
            <div>
                <h2 class="text-lg font-bold text-gray-800">Lengkapi Profil Pendaftar</h2>
                <p class="text-sm text-gray-600">Data disimpan sebagai draft dan dapat dilengkapi bertahap.</p>
            </div>
            <span class="rounded-full bg-blue-50 px-3 py-1 text-sm font-semibold text-blue-700">
                <?php echo e($profile?->completionPercentage() ?? 0); ?>% lengkap
            </span>
        </div>

        <ol class="mt-5 grid grid-cols-2 gap-2 md:grid-cols-4">
            <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nomor => $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $aktif = $step === $nomor;
                    $selesai = in_array($nomor, $completed, true);
                ?>
                <li>
                    <a href="<?php echo e(route('pendaftar.profil.step', $nomor)); ?>"
                        class="block rounded-lg border px-3 py-2 text-sm transition
                            <?php echo e($aktif
                                ? 'border-blue-600 bg-blue-50 font-semibold text-blue-700'
                                : ($selesai
                                    ? 'border-green-300 bg-green-50 text-green-700'
                                    : 'border-gray-200 text-gray-600 hover:border-blue-300')); ?>">
                        <span class="block text-xs opacity-75">Langkah <?php echo e($nomor); ?></span>
                        <?php echo e($info['judul']); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
    </div>

    
    <div class="bg-white shadow rounded-xl p-6">
        <h3 class="text-lg font-bold text-gray-800">Langkah <?php echo e($step); ?>: <?php echo e($steps[$step]['judul']); ?></h3>
        <p class="mt-1 text-sm text-gray-500 mb-5">
            <?php switch($step):
                case (1): ?>
                    Isi data identitas sesuai dokumen resmi (KTP/Kartu Keluarga dan ijazah).
                    <?php break; ?>
                <?php case (2): ?>
                    Isi alamat tempat tinggal yang dapat dihubungi saat proses verifikasi.
                    <?php break; ?>
                <?php case (3): ?>
                    Isi data sekolah asal dan tahun kelulusan.
                    <?php break; ?>
                <?php case (4): ?>
                    Isi data orang tua/wali dan pilih golongan UKT yang sesuai dengan penghasilan.
                    <?php break; ?>
            <?php endswitch; ?>
        </p>

        <form method="POST" action="<?php echo e(route('pendaftar.profil.step.update', $step)); ?>">
            <?php echo csrf_field(); ?>

            <?php
                $inputClass = 'mt-1 block w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500';
                $labelClass = 'block text-sm font-medium text-gray-700';
                $errorClass = 'mt-1 text-sm text-red-600';
            ?>

            <?php echo $__env->make('pendaftar.profil.steps.step-'.$step, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <div class="mt-6 flex flex-wrap items-center gap-3 border-t border-gray-100 pt-5">
                <?php if($step > 1): ?>
                    <a href="<?php echo e(route('pendaftar.profil.step', $step - 1)); ?>"
                        class="rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50">
                        Kembali
                    </a>
                <?php endif; ?>

                <button type="submit"
                    class="rounded-lg bg-blue-600 px-5 py-2 text-sm font-semibold text-white hover:bg-blue-700">
                    <?php echo e($step < 4 ? 'Simpan & Lanjut' : 'Simpan & Pilih Jalur'); ?>

                </button>

                <a href="<?php echo e(route('pendaftar.dashboard')); ?>" class="text-sm text-gray-500 hover:underline">
                    Kembali ke dashboard
                </a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pendaftar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/pendaftar/profil/step.blade.php ENDPATH**/ ?>