<?php $__env->startSection('title', 'Dokumen Pendaftaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">

    
    <div class="bg-white shadow rounded-xl p-6 mb-6">
        <div class="flex flex-wrap items-start justify-between gap-3">
            <div>
                <h2 class="text-lg font-bold text-gray-800">Dokumen Pendaftaran</h2>
                <p class="mt-1 text-sm text-gray-600">
                    Persyaratan dokumen untuk jalur
                    <strong><?php echo e($pendaftaran->jalur?->nama ?? '-'); ?></strong>
                    <?php if($pendaftaran->prodi): ?>
                        &middot; <?php echo e($pendaftaran->prodi->nama); ?>

                    <?php endif; ?>
                </p>
            </div>

            <div class="text-right text-sm">
                <span class="inline-block rounded-full px-3 py-1 text-xs font-semibold <?php echo e($pendaftaran->isDraft() ? 'bg-blue-100 text-blue-700' : 'bg-amber-100 text-amber-700'); ?>">
                    <?php echo e($pendaftaran->statusLabel()); ?>

                </span>
                <?php if($pendaftaran->nomor_pendaftaran): ?>
                    <div class="mt-2 font-mono text-xs text-gray-600"><?php echo e($pendaftaran->nomor_pendaftaran); ?></div>
                <?php endif; ?>
            </div>
        </div>

        <?php if(! $bolehUpload): ?>
            <p class="mt-4 rounded-lg bg-amber-50 px-4 py-3 text-sm text-amber-800">
                Dokumen terkunci karena pendaftaran sudah berstatus
                <strong><?php echo e($pendaftaran->statusLabel()); ?></strong>.
                <?php if($pendaftaran->status === 'ditolak'): ?>
                    Silakan unggah ulang dokumen yang ditolak lalu ajukan verifikasi kembali.
                <?php endif; ?>
            </p>
        <?php endif; ?>

        <?php if($pendaftaran->catatan_admin): ?>
            <div class="mt-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
                <strong>Catatan panitia:</strong> <?php echo e($pendaftaran->catatan_admin); ?>

            </div>
        <?php endif; ?>
    </div>

    
    <div class="space-y-4 mb-6">
        <?php $__empty_1 = true; $__currentLoopData = $dokumen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $master = $item['master'];
                $upload = $item['upload'];
                $status = $item['status'];
            ?>

            <div class="bg-white shadow rounded-xl p-5">
                <div class="flex flex-wrap items-start justify-between gap-3">
                    <div>
                        <h3 class="font-semibold text-gray-800">
                            <?php echo e($master->nama); ?>

                            <?php if($item['wajib']): ?>
                                <span class="ml-1 rounded bg-red-50 px-2 py-0.5 text-xs font-semibold text-red-600">Wajib</span>
                            <?php else: ?>
                                <span class="ml-1 rounded bg-gray-100 px-2 py-0.5 text-xs font-semibold text-gray-600">Opsional</span>
                            <?php endif; ?>
                        </h3>
                        <p class="mt-1 text-xs text-gray-500">
                            Kode <?php echo e($master->kode); ?> &middot; Maksimal <?php echo e($master->max_size); ?> KB &middot; Format JPG, PNG, atau PDF
                        </p>
                    </div>

                    <span class="rounded-full px-3 py-1 text-xs font-semibold
                        <?php if($status === 'valid'): ?>
                            bg-green-100 text-green-700
                        <?php elseif($status === 'menunggu'): ?>
                            bg-amber-100 text-amber-700
                        <?php elseif($status === 'ditolak'): ?>
                            bg-red-100 text-red-700
                        <?php else: ?>
                            bg-gray-100 text-gray-600
                        <?php endif; ?>">
                        <?php echo e($item['label']); ?>

                    </span>
                </div>

                <?php if($upload && $upload->file_path): ?>
                    <div class="mt-3 flex flex-wrap items-center gap-3 text-sm">
                        <span class="text-gray-600">Berkas: <?php echo e(basename($upload->file_path)); ?></span>
                        <a href="<?php echo e(route('pendaftar.dokumen.download', $master)); ?>"
                            class="text-blue-600 hover:underline">Unduh berkas</a>
                    </div>
                <?php endif; ?>

                <?php if($upload && $upload->catatan_admin): ?>
                    <div class="mt-3 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
                        <strong>Catatan panitia:</strong> <?php echo e($upload->catatan_admin); ?>

                    </div>
                <?php endif; ?>

                <?php if($bolehUpload): ?>
                    <form method="POST" action="<?php echo e(route('pendaftar.dokumen.upload', $master)); ?>"
                        enctype="multipart/form-data" class="mt-4 flex flex-wrap items-end gap-3">
                        <?php echo csrf_field(); ?>

                        <div class="flex-1 min-w-[220px]">
                            <label for="file-<?php echo e($master->id); ?>" class="block text-sm font-medium text-gray-700">
                                <?php echo e($upload ? 'Ganti berkas' : 'Unggah berkas'); ?>

                            </label>
                            <input type="file" id="file-<?php echo e($master->id); ?>" name="file"
                                accept=".jpg,.jpeg,.png,.pdf" class="mt-1 block w-full text-sm text-gray-600
                                    file:mr-3 file:rounded-lg file:border-0 file:bg-blue-50 file:px-3 file:py-2 file:text-sm file:font-medium file:text-blue-700">
                            <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <button type="submit"
                            class="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700">
                            <?php echo e($upload ? 'Ganti' : 'Upload'); ?>

                        </button>
                    </form>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-gray-500">Belum ada dokumen yang dipersyaratkan untuk jalur ini.</p>
        <?php endif; ?>
    </div>

    
    <div class="bg-white shadow rounded-xl p-6">
        <h3 class="font-bold text-lg">Ajukan Verifikasi</h3>

        <?php if($bolehAjukan): ?>
            <p class="mt-2 text-sm text-gray-600">
                Semua dokumen wajib sudah diunggah. Setelah diajukan, jalur dan program studi terkunci
                dan pendaftaran menunggu pemeriksaan panitia.
            </p>

            <form method="POST" action="<?php echo e(route('pendaftar.dokumen.verifikasi')); ?>" class="mt-4">
                <?php echo csrf_field(); ?>
                <button type="submit"
                    class="rounded-lg bg-green-600 px-5 py-2 text-sm font-semibold text-white hover:bg-green-700">
                    Ajukan Verifikasi
                </button>
            </form>
        <?php else: ?>
            <p class="mt-2 text-sm text-gray-600">
                Tombol pengajuan aktif setelah semua dokumen wajib berstatus
                <strong>Menunggu Verifikasi</strong> atau <strong>Valid</strong>.
            </p>

            <?php if($dokumen->filter(fn ($item): bool => $item['wajib'] && ! $item['lengkap'])->isNotEmpty()): ?>
                <ul class="mt-3 space-y-1 text-sm text-red-700">
                    <?php $__currentLoopData = $dokumen->filter(fn ($item): bool => $item['wajib'] && ! $item['lengkap']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>- <?php echo e($item['master']->nama); ?> (<?php echo e($item['label']); ?>)</li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pendaftar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/pendaftar/dokumen.blade.php ENDPATH**/ ?>