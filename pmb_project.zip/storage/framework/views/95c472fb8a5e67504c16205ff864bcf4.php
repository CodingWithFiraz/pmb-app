<?php $__env->startSection('title', 'Dokumen Persyaratan'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold">Dokumen Persyaratan</h1>
    <a href="<?php echo e(route('admin.dokumen.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700">+ Tambah Dokumen</a>
</div>

<div class="bg-white shadow rounded-xl overflow-hidden">
    <table class="w-full text-sm">
        <thead class="bg-gray-50 text-gray-600">
            <tr>
                <th class="text-left px-4 py-3">Kode</th>
                <th class="text-left px-4 py-3">Nama</th>
                <th class="text-left px-4 py-3">Tipe</th>
                <th class="text-left px-4 py-3">Max Size</th>
                <th class="text-left px-4 py-3">Wajib</th>
                <th class="text-left px-4 py-3">Jalur</th>
                <th class="px-4 py-3"></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $dokumen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-t">
                    <td class="px-4 py-3 font-mono font-bold"><?php echo e($d->kode); ?></td>
                    <td class="px-4 py-3 font-medium"><?php echo e($d->nama); ?></td>
                    <td class="px-4 py-3 text-gray-600 uppercase"><?php echo e($d->tipe_file); ?></td>
                    <td class="px-4 py-3 text-gray-600"><?php echo e($d->max_size); ?> KB</td>
                    <td class="px-4 py-3">
                        <?php if($d->is_wajib): ?>
                            <span class="px-2 py-0.5 rounded text-xs font-medium bg-red-50 text-red-700">Wajib</span>
                        <?php else: ?>
                            <span class="px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-600">Opsional</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-4 py-3 text-gray-600"><?php echo e($d->jalur_count); ?> jalur</td>
                    <td class="px-4 py-3">
                        <div class="flex items-center gap-3">
                            <a href="<?php echo e(route('admin.dokumen.mapping', $d)); ?>" class="text-blue-600 hover:underline text-xs">Mapping Jalur</a>
                            <a href="<?php echo e(route('admin.dokumen.edit', $d)); ?>" class="text-blue-600 hover:underline text-xs">Edit</a>

                            <form method="POST" action="<?php echo e(route('admin.dokumen.destroy', $d)); ?>"
                                onsubmit="return confirm('Hapus dokumen ini beserta mapping jalurnya?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:underline text-xs">Hapus</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-center py-8 text-gray-500">Belum ada dokumen.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-4"><?php echo e($dokumen->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/admin/dokumen/index.blade.php ENDPATH**/ ?>