<?php $__env->startSection('title', 'Dashboard Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-5xl mx-auto">
    <?php if($activePeriod): ?>
        <div class="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6 text-blue-800">
            Periode Aktif: <strong><?php echo e($activePeriod->nama); ?></strong>
            (<?php echo e($activePeriod->tanggal_mulai->translatedFormat('d M Y')); ?> &mdash; <?php echo e($activePeriod->tanggal_selesai->translatedFormat('d M Y')); ?>)
        </div>
    <?php endif; ?>

    
    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
        <?php $__currentLoopData = [
            ['label' => 'Total Pendaftar', 'value' => $stats['total'],               'color' => 'bg-gray-100 text-gray-800'],
            ['label' => 'Menunggu Verifikasi', 'value' => $stats['menunggu_verifikasi'], 'color' => 'bg-amber-100 text-amber-700'],
            ['label' => 'Terverifikasi',    'value' => $stats['terverifikasi'],       'color' => 'bg-green-100 text-green-700'],
            ['label' => 'Sudah Bayar',      'value' => $stats['sudah_bayar'],         'color' => 'bg-blue-100 text-blue-700'],
            ['label' => 'Belum Bayar',      'value' => $stats['belum_bayar'],         'color' => 'bg-red-100 text-red-700'],
            ['label' => 'Tagihan Menunggu', 'value' => $stats['menunggu_bayar'],      'color' => 'bg-gray-100 text-gray-700'],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white shadow rounded-xl p-4 text-center">
                <div class="text-2xl font-bold <?php echo e($stat['color']); ?> rounded-lg py-1" data-stat="<?php echo e($stat['label']); ?>"><?php echo e($stat['value']); ?></div>
                <div class="text-xs text-gray-600 mt-1"><?php echo e($stat['label']); ?></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-5 mb-8">
        
        <div class="bg-white shadow rounded-xl p-6">
            <h2 class="font-bold text-lg mb-4">Pendaftar per Jalur</h2>

            <?php if($jalurList->isEmpty()): ?>
                <p class="text-gray-500 text-sm">Belum ada jalur masuk.</p>
            <?php else: ?>
                <ul class="space-y-3">
                    <?php $__currentLoopData = $jalurList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li data-jalur="<?php echo e($j['kode']); ?>">
                            <div class="flex items-center justify-between text-sm mb-1">
                                <span class="text-gray-700"><?php echo e($j['nama']); ?></span>
                                <span class="font-semibold text-gray-800" data-jalur-total="<?php echo e($j['kode']); ?>"><?php echo e($j['total']); ?></span>
                            </div>
                            <div class="h-2 w-full rounded bg-gray-100">
                                <div class="h-2 rounded bg-blue-600"
                                    style="width: <?php echo e($stats['total'] > 0 ? round($j['total'] / $stats['total'] * 100) : 0); ?>%"></div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>

        
        <div class="bg-white shadow rounded-xl p-6">
            <h2 class="font-bold text-lg mb-4">Status Pendaftaran</h2>

            <ul class="space-y-2 text-sm">
                <li class="flex items-center justify-between">
                    <span class="text-gray-600">Draft</span>
                    <span class="font-semibold text-gray-800"><?php echo e($stats['draft']); ?></span>
                </li>
                <li class="flex items-center justify-between">
                    <span class="text-gray-600">Menunggu Verifikasi</span>
                    <span class="font-semibold text-gray-800"><?php echo e($stats['menunggu_verifikasi']); ?></span>
                </li>
                <li class="flex items-center justify-between">
                    <span class="text-gray-600">Terverifikasi</span>
                    <span class="font-semibold text-gray-800"><?php echo e($stats['terverifikasi']); ?></span>
                </li>
                <li class="flex items-center justify-between">
                    <span class="text-gray-600">Ditolak</span>
                    <span class="font-semibold text-gray-800"><?php echo e($stats['ditolak']); ?></span>
                </li>
            </ul>
        </div>

        
        <div class="bg-white shadow rounded-xl p-6">
            <h2 class="font-bold text-lg mb-4">Ringkasan Pembayaran</h2>

            <ul class="space-y-2 text-sm">
                <li class="flex items-center justify-between">
                    <span class="text-gray-600">Total tagihan</span>
                    <span class="font-semibold text-gray-800"><?php echo e($ringkasanTagihan['total']); ?></span>
                </li>
                <li class="flex items-center justify-between">
                    <span class="text-gray-600">Lunas</span>
                    <span class="font-semibold text-green-700"><?php echo e($ringkasanTagihan['paid']); ?></span>
                </li>
                <li class="flex items-center justify-between">
                    <span class="text-gray-600">Menunggu pembayaran</span>
                    <span class="font-semibold text-amber-700"><?php echo e($ringkasanTagihan['pending']); ?></span>
                </li>
                <li class="flex items-center justify-between">
                    <span class="text-gray-600">Kedaluwarsa / gagal</span>
                    <span class="font-semibold text-red-700"><?php echo e($ringkasanTagihan['gagal']); ?></span>
                </li>
            </ul>
        </div>
    </div>

    
    <div class="bg-white shadow rounded-xl p-6">
        <h2 class="font-bold text-lg mb-4">10 Pendaftar Terbaru</h2>

        <?php if($recentPendaftar->isEmpty()): ?>
            <p class="text-gray-500">Belum ada pendaftar.</p>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="bg-gray-50 text-gray-600">
                        <tr>
                            <th class="text-left px-3 py-2">No. Daftar</th>
                            <th class="text-left px-3 py-2">Nama</th>
                            <th class="text-left px-3 py-2">Jalur</th>
                            <th class="text-left px-3 py-2">Program Studi</th>
                            <th class="text-left px-3 py-2">Status</th>
                            <th class="px-3 py-2"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $recentPendaftar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-t">
                                <td class="px-3 py-2 font-mono text-xs"><?php echo e($p->nomor_pendaftaran ?? '-'); ?></td>
                                <td class="px-3 py-2"><?php echo e($p->user->name); ?></td>
                                <td class="px-3 py-2 text-gray-600"><?php echo e($p->jalur?->kode ?? '-'); ?></td>
                                <td class="px-3 py-2 text-gray-600"><?php echo e($p->prodi?->nama ?? '-'); ?></td>
                                <td class="px-3 py-2">
                                    <span class="px-2 py-0.5 rounded text-xs font-medium
                                        <?php if($p->status === 'terverifikasi'): ?>
                                            bg-green-100 text-green-700
                                        <?php elseif($p->status === 'ditolak'): ?>
                                            bg-red-100 text-red-700
                                        <?php elseif($p->status === 'menunggu_verifikasi'): ?>
                                            bg-amber-100 text-amber-700
                                        <?php else: ?>
                                            bg-gray-100 text-gray-700
                                        <?php endif; ?>">
                                        <?php echo e($p->statusLabel()); ?>

                                    </span>
                                </td>
                                <td class="px-3 py-2">
                                    <a href="<?php echo e(route('admin.pendaftaran.show', $p)); ?>" class="text-blue-600 hover:underline text-xs">Detail</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>