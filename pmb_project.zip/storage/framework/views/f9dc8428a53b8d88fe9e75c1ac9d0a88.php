<?php $__env->startSection('title', 'Jalur Masuk'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold">Jalur Masuk</h1>
    <a href="<?php echo e(route('admin.jalur-masuk.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700">+ Tambah Jalur</a>
</div>

<div class="bg-white shadow rounded-xl overflow-hidden">
    <table class="w-full text-sm">
        <thead class="bg-gray-50 text-gray-600">
            <tr>
                <th class="text-left px-4 py-3">Urutan</th>
                <th class="text-left px-4 py-3">Kode</th>
                <th class="text-left px-4 py-3">Nama</th>
                <th class="text-left px-4 py-3">Biaya Pendaftaran</th>
                <th class="text-left px-4 py-3">Dokumen</th>
                <th class="px-4 py-3"></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $jalur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-t">
                    <td class="px-4 py-3 text-gray-600"><?php echo e($j->urutan); ?></td>
                    <td class="px-4 py-3 font-mono font-bold"><?php echo e($j->kode); ?></td>
                    <td class="px-4 py-3 font-medium"><?php echo e($j->nama); ?></td>
                    <td class="px-4 py-3">
                        <?php if($j->punya_biaya_pendaftaran): ?>
                            <span class="px-2 py-0.5 rounded text-xs font-medium bg-amber-100 text-amber-700">Berbayar</span>
                        <?php else: ?>
                            <span class="px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-700">Gratis</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-4 py-3 text-gray-600"><?php echo e($j->dokumen_count); ?></td>
                    <td class="px-4 py-3">
                        <div class="flex items-center gap-3">
                            <a href="<?php echo e(route('admin.jalur-masuk.edit', $j)); ?>" class="text-blue-600 hover:underline text-xs">Edit</a>

                            <form method="POST" action="<?php echo e(route('admin.jalur-masuk.destroy', $j)); ?>"
                                onsubmit="return confirm('Hapus jalur masuk ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:underline text-xs">Hapus</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="text-center py-8 text-gray-500">Belum ada jalur masuk.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-4"><?php echo e($jalur->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/admin/jalur/index.blade.php ENDPATH**/ ?>