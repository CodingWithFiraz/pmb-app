<?php $__env->startSection('title', 'Berita'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold">Berita</h1>
    <a href="<?php echo e(route('admin.berita.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700">+ Tambah Berita</a>
</div>

<form method="GET" class="bg-white shadow rounded-xl p-4 mb-6 flex flex-wrap gap-3 items-end">
    <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Cari judul berita..."
        class="border rounded-lg px-3 py-2 text-sm flex-1 min-w-48 focus:ring-2 focus:ring-blue-500">

    <select name="status" class="border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500">
        <option value="">Semua Status</option>
        <option value="draft" <?php echo e(request('status') === 'draft' ? 'selected' : ''); ?>>Draft</option>
        <option value="publish" <?php echo e(request('status') === 'publish' ? 'selected' : ''); ?>>Publish</option>
    </select>

    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700">Filter</button>
    <a href="<?php echo e(route('admin.berita.index')); ?>" class="border border-gray-300 text-gray-600 px-4 py-2 rounded-lg text-sm hover:bg-gray-50">Reset</a>
</form>

<div class="bg-white shadow rounded-xl overflow-hidden">
    <table class="w-full text-sm">
        <thead class="bg-gray-50 text-gray-600">
            <tr>
                <th class="text-left px-4 py-3">Judul</th>
                <th class="text-left px-4 py-3">Penulis</th>
                <th class="text-left px-4 py-3">Tanggal Publish</th>
                <th class="text-left px-4 py-3">Status</th>
                <th class="px-4 py-3"></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-t">
                    <td class="px-4 py-3">
                        <div class="font-medium"><?php echo e($b->judul); ?></div>
                        <div class="text-xs text-gray-500">/<?php echo e($b->slug); ?></div>
                    </td>
                    <td class="px-4 py-3 text-gray-600"><?php echo e($b->author); ?></td>
                    <td class="px-4 py-3 text-gray-600"><?php echo e($b->published_at?->translatedFormat('d M Y H:i') ?? '-'); ?></td>
                    <td class="px-4 py-3">
                        <?php if($b->isTayang()): ?>
                            <span class="px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-700">Tayang</span>
                        <?php elseif($b->status === 'publish'): ?>
                            <span class="px-2 py-0.5 rounded text-xs font-medium bg-amber-100 text-amber-700">Terjadwal</span>
                        <?php else: ?>
                            <span class="px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-600">Draft</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-4 py-3">
                        <div class="flex items-center gap-3">
                            <a href="<?php echo e(route('admin.berita.edit', $b)); ?>" class="text-blue-600 hover:underline text-xs">Edit</a>

                            <form method="POST" action="<?php echo e(route('admin.berita.destroy', $b)); ?>"
                                onsubmit="return confirm('Hapus berita ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:underline text-xs">Hapus</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="text-center py-8 text-gray-500">Belum ada berita.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-4"><?php echo e($berita->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/admin/berita/index.blade.php ENDPATH**/ ?>