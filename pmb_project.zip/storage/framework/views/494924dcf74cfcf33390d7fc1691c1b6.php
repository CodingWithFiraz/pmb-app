<?php $__env->startSection('title', 'Detail Pendaftar'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold">Detail Pendaftar</h1>
        <a href="<?php echo e(route('admin.pendaftaran.index')); ?>" class="text-blue-600 hover:underline text-sm">&larr; Kembali</a>
    </div>

    
    <div class="bg-white shadow rounded-xl p-6 mb-4">
        <div class="flex justify-between gap-4">
            <div>
                <div class="text-2xl font-bold"><?php echo e($pendaftaran->user->name); ?></div>
                <div class="text-gray-600">
                    <?php echo e($pendaftaran->prodi->nama); ?> &middot; <?php echo e($pendaftaran->periode->nama); ?>

                </div>
                <?php if($pendaftaran->nomor_pendaftaran): ?>
                    <div class="font-mono text-blue-700 text-sm mt-1"><?php echo e($pendaftaran->nomor_pendaftaran); ?></div>
                <?php endif; ?>
            </div>
            <div class="text-right">
                <span class="px-4 py-1 rounded-full font-semibold
                    <?php if($pendaftaran->status === 'terverifikasi'): ?>
                        bg-green-100 text-green-700
                    <?php elseif($pendaftaran->status === 'ditolak'): ?>
                        bg-red-100 text-red-700
                    <?php elseif($pendaftaran->status === 'menunggu_verifikasi'): ?>
                        bg-amber-100 text-amber-700
                    <?php else: ?>
                        bg-gray-100 text-gray-700
                    <?php endif; ?>">
                    <?php echo e($pendaftaran->statusLabel()); ?>

                </span>
                <div class="text-xs text-gray-500 mt-1">Kelulusan: <?php echo e($pendaftaran->hasil_kelulusan); ?></div>
            </div>
        </div>

        <?php if($pendaftaran->catatan_admin): ?>
            <div class="mt-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
                <strong>Catatan panitia:</strong> <?php echo e($pendaftaran->catatan_admin); ?>

            </div>
        <?php endif; ?>
    </div>

    
    <div class="bg-white shadow rounded-xl p-6 mb-4">
        <h2 class="font-bold text-blue-700 mb-3">Data Pribadi</h2>
        <dl class="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
            <dt class="text-gray-500">Email</dt><dd><?php echo e($pendaftaran->user->email); ?></dd>
            <dt class="text-gray-500">No. HP</dt><dd><?php echo e($pendaftaran->user->phone ?? '-'); ?></dd>
            <dt class="text-gray-500">NIK</dt><dd><?php echo e($pendaftaran->user->profile?->nik ?? '-'); ?></dd>
            <dt class="text-gray-500">NISN</dt><dd><?php echo e($pendaftaran->user->profile?->nisn ?? '-'); ?></dd>
            <dt class="text-gray-500">Jenis Kelamin</dt>
            <dd><?php echo e($pendaftaran->user->profile?->jenis_kelamin === 'L' ? 'Laki-laki' : ($pendaftaran->user->profile?->jenis_kelamin === 'P' ? 'Perempuan' : '-')); ?></dd>
            <dt class="text-gray-500">Tgl Lahir</dt>
            <dd>
                <?php if($pendaftaran->user->profile?->tanggal_lahir): ?>
                    <?php echo e($pendaftaran->user->profile->tanggal_lahir->format('d M Y')); ?> &middot; <?php echo e($pendaftaran->user->profile->tempat_lahir); ?>

                <?php else: ?>
                    -
                <?php endif; ?>
            </dd>
            <dt class="text-gray-500">Alamat</dt>
            <dd>
                <?php if($pendaftaran->user->profile?->alamat): ?>
                    <?php echo e($pendaftaran->user->profile->alamat); ?>, <?php echo e($pendaftaran->user->profile->kota); ?>, <?php echo e($pendaftaran->user->profile->provinsi); ?>

                <?php else: ?>
                    -
                <?php endif; ?>
            </dd>
        </dl>
    </div>

    
    <div class="bg-white shadow rounded-xl p-6 mb-4">
        <h2 class="font-bold text-blue-700 mb-3">Data Pendidikan & Orang Tua</h2>
        <dl class="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
            <dt class="text-gray-500">Sekolah</dt><dd><?php echo e($pendaftaran->user->profile?->asal_sekolah ?? '-'); ?></dd>
            <dt class="text-gray-500">Tahun Lulus</dt><dd><?php echo e($pendaftaran->user->profile?->tahun_lulus ?? '-'); ?></dd>
            <dt class="text-gray-500">Nama Orang Tua</dt><dd><?php echo e($pendaftaran->user->profile?->nama_ortu ?? '-'); ?></dd>
            <dt class="text-gray-500">Pekerjaan Orang Tua</dt><dd><?php echo e($pendaftaran->user->profile?->pekerjaan_ortu ?? '-'); ?></dd>
            <dt class="text-gray-500">Penghasilan Orang Tua</dt>
            <dd>
                <?php if($pendaftaran->user->profile?->penghasilan_ortu): ?>
                    Rp <?php echo e(number_format($pendaftaran->user->profile->penghasilan_ortu, 0, ',', '.')); ?>

                <?php else: ?>
                    -
                <?php endif; ?>
            </dd>
            <dt class="text-gray-500">Golongan UKT</dt><dd><?php echo e($pendaftaran->golongan->nama); ?></dd>
        </dl>
    </div>

    
    <div class="bg-white shadow rounded-xl p-6 mb-4">
        <h2 class="font-bold text-blue-700 mb-3">Data Pendaftaran</h2>
        <dl class="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
            <dt class="text-gray-500">Jalur Masuk</dt><dd><?php echo e($pendaftaran->jalur->nama); ?></dd>
            <dt class="text-gray-500">Program Studi</dt>
            <dd>
                <?php echo e($pendaftaran->prodi->nama); ?> (<?php echo e($pendaftaran->prodi->kode); ?>) &middot;
                <?php echo e($pendaftaran->prodi->fakultas->nama); ?>

            </dd>
            <dt class="text-gray-500">Pilihan 2</dt><dd><?php echo e($pendaftaran->prodiAlternatif->nama ?? '-'); ?></dd>
            <dt class="text-gray-500">Periode</dt>
            <dd><?php echo e($pendaftaran->periode->nama); ?> (TA <?php echo e($pendaftaran->periode->tahun_akademik); ?>)</dd>
            <dt class="text-gray-500">Diverifikasi Oleh</dt><dd><?php echo e($pendaftaran->verifier->name ?? '-'); ?></dd>
            <dt class="text-gray-500">Tgl Verifikasi</dt>
            <dd><?php echo e($pendaftaran->verified_at?->format('d/m/Y H:i') ?? '-'); ?></dd>
        </dl>
    </div>

    
    <div class="bg-white shadow rounded-xl p-6 mb-4">
        <h2 class="font-bold text-blue-700 mb-3">Dokumen Persyaratan</h2>

        <div class="space-y-3">
            <?php $__empty_1 = true; $__currentLoopData = $dokumen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $master = $item['master'];
                    $upload = $item['upload'];
                    $status = $item['status'];
                ?>

                <div class="border rounded-lg px-4 py-3">
                    <div class="flex flex-wrap items-center justify-between gap-2">
                        <div>
                            <div class="font-medium text-sm">
                                <?php echo e($master->nama); ?>

                                <?php if($item['wajib']): ?>
                                    <span class="ml-1 rounded bg-red-50 px-2 py-0.5 text-xs font-semibold text-red-600">Wajib</span>
                                <?php else: ?>
                                    <span class="ml-1 rounded bg-gray-100 px-2 py-0.5 text-xs font-semibold text-gray-600">Opsional</span>
                                <?php endif; ?>
                            </div>
                            <div class="text-xs text-gray-500">Kode <?php echo e($master->kode); ?></div>
                        </div>

                        <span class="rounded-full px-3 py-1 text-xs font-semibold
                            <?php if($status === 'valid'): ?>
                                bg-green-100 text-green-700
                            <?php elseif($status === 'ditolak'): ?>
                                bg-red-100 text-red-700
                            <?php elseif($status === 'menunggu'): ?>
                                bg-amber-100 text-amber-700
                            <?php else: ?>
                                bg-gray-100 text-gray-600
                            <?php endif; ?>">
                            <?php if($status === 'valid'): ?>
                                Valid
                            <?php elseif($status === 'ditolak'): ?>
                                Ditolak
                            <?php elseif($status === 'menunggu'): ?>
                                Menunggu Verifikasi
                            <?php else: ?>
                                Belum Diunggah
                            <?php endif; ?>
                        </span>
                    </div>

                    <?php if($upload): ?>
                        <div class="mt-2 flex flex-wrap items-center gap-3 text-sm">
                            <a href="<?php echo e(route('admin.dokumen.unduh', $upload)); ?>" class="text-blue-600 hover:underline">
                                Unduh <?php echo e(basename($upload->file_path)); ?>

                            </a>
                        </div>

                        <?php if($upload->catatan_admin): ?>
                            <div class="mt-2 rounded-lg bg-red-50 px-3 py-2 text-xs text-red-700">
                                Catatan: <?php echo e($upload->catatan_admin); ?>

                            </div>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route('admin.dokumen.status', $upload)); ?>"
                            class="mt-3 flex flex-wrap items-end gap-2 border-t border-gray-100 pt-3">
                            <?php echo csrf_field(); ?>

                            <div class="flex-1 min-w-[220px]">
                                <label for="catatan-<?php echo e($upload->id); ?>" class="block text-xs font-medium text-gray-600">
                                    Catatan panitia
                                </label>
                                <input type="text" id="catatan-<?php echo e($upload->id); ?>" name="catatan"
                                    value="<?php echo e(old('catatan', $upload->catatan_admin)); ?>"
                                    class="mt-1 block w-full rounded-lg border-gray-300 text-sm"
                                    placeholder="Wajib diisi bila menolak dokumen">
                                <?php $__errorArgs = ['catatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <button type="submit" name="status" value="valid"
                                class="rounded-lg bg-green-600 px-4 py-2 text-sm font-semibold text-white hover:bg-green-700">
                                Tandai Valid
                            </button>
                            <button type="submit" name="status" value="ditolak"
                                class="rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-700">
                                Tolak Dokumen
                            </button>
                        </form>
                    <?php else: ?>
                        <p class="mt-2 text-xs text-gray-500">Pendaftar belum mengunggah dokumen ini.</p>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-gray-500 text-sm">Jalur ini tidak memiliki persyaratan dokumen.</p>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="bg-white shadow rounded-xl p-6 mb-4">
        <h2 class="font-bold text-blue-700 mb-3">Verifikasi Pendaftar</h2>

        <?php if($pendaftaran->status === 'terverifikasi'): ?>
            <p class="text-sm text-green-700">
                Pendaftaran sudah terverifikasi
                <?php if($pendaftaran->verifier): ?>
                    oleh <?php echo e($pendaftaran->verifier->name); ?>

                <?php endif; ?>
                pada <?php echo e($pendaftaran->verified_at?->format('d/m/Y H:i')); ?>.
                Tagihan otomatis sudah dibuat.
            </p>
        <?php else: ?>
            <?php if($siapVerifikasi): ?>
                <p class="text-sm text-gray-600 mb-3">Semua dokumen wajib sudah valid. Pendaftaran dapat diverifikasi.</p>

                <form method="POST" action="<?php echo e(route('admin.pendaftaran.verifikasi', $pendaftaran)); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit"
                        class="rounded-lg bg-green-600 px-5 py-2 text-sm font-semibold text-white hover:bg-green-700">
                        Verifikasi Pendaftar
                    </button>
                </form>
            <?php else: ?>
                <p class="text-sm text-gray-600 mb-2">Tombol verifikasi aktif setelah semua dokumen wajib berstatus Valid.</p>

                <ul class="space-y-1 text-sm text-amber-700">
                    <?php $__currentLoopData = $dokumen->filter(fn ($item) => $item['wajib'] && $item['status'] !== 'valid'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>- <?php echo e($item['master']->nama); ?> (<?php echo e($item['status'] === 'belum' ? 'belum diunggah' : $item['status']); ?>)</li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>

            <div class="mt-6 border-t border-gray-100 pt-4">
                <h3 class="font-semibold text-sm text-gray-700">Tolak Pendaftaran</h3>
                <p class="mt-1 text-xs text-gray-500">
                    Pendaftar akan dapat merevisi dokumen dan mengajukan ulang pendaftaran.
                </p>

                <form method="POST" action="<?php echo e(route('admin.pendaftaran.tolak', $pendaftaran)); ?>" class="mt-3">
                    <?php echo csrf_field(); ?>

                    <label for="catatan-tolak" class="block text-sm font-medium text-gray-700">Catatan penolakan</label>
                    <textarea name="catatan" id="catatan-tolak" rows="2" required
                        class="mt-1 block w-full rounded-lg border-gray-300 text-sm"
                        placeholder="Contoh: Berkas rapor kurang halaman."><?php echo e(old('catatan')); ?></textarea>
                    <?php $__errorArgs = ['catatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <button type="submit"
                        class="mt-3 rounded-lg bg-red-600 px-5 py-2 text-sm font-semibold text-white hover:bg-red-700">
                        Tolak Pendaftaran
                    </button>
                </form>
            </div>
        <?php endif; ?>
    </div>

    
    <div class="bg-white shadow rounded-xl p-6">
        <h2 class="font-bold text-blue-700 mb-3">Tagihan Pembayaran</h2>
        <?php if($pendaftaran->pembayaran->isEmpty()): ?>
            <p class="text-gray-500 text-sm">Belum ada tagihan. Tagihan dibuat otomatis saat pendaftaran diverifikasi.</p>
        <?php else: ?>
            <div class="space-y-2">
                <?php $__currentLoopData = $pendaftaran->pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bayar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center justify-between border rounded-lg px-3 py-2 text-sm">
                        <div>
                            <div class="font-medium"><?php echo e($bayar->jenis === 'ukt' ? 'UKT' : 'Biaya Pendaftaran'); ?></div>
                            <div class="text-xs text-gray-500">
                                <?php echo e($bayar->metode ?? '-'); ?> &middot;
                                <?php if($bayar->status === 'paid'): ?>
                                    Lunas
                                <?php elseif($bayar->status === 'pending'): ?>
                                    Menunggu Pembayaran
                                <?php elseif($bayar->status === 'expired'): ?>
                                    Kedaluwarsa
                                <?php else: ?>
                                    <?php echo e($bayar->status); ?>

                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="font-semibold">Rp <?php echo e(number_format($bayar->nominal, 0, ',', '.')); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/admin/pendaftaran/show.blade.php ENDPATH**/ ?>