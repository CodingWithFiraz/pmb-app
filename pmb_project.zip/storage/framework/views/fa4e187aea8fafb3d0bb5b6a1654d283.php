<div class="space-y-5">
    <div>
        <label for="alamat" class="<?php echo e($labelClass); ?>">Alamat Lengkap <span class="text-red-500">*</span></label>
        <textarea name="alamat" id="alamat" rows="3" class="<?php echo e($inputClass); ?>"
            placeholder="Jalan, nomor rumah, RT/RW, kelurahan, kecamatan"><?php echo e(old('alamat', $profile?->alamat)); ?></textarea>
        <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="<?php echo e($errorClass); ?>"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
        <div>
            <label for="provinsi" class="<?php echo e($labelClass); ?>">Provinsi <span class="text-red-500">*</span></label>
            <input type="text" name="provinsi" id="provinsi"
                value="<?php echo e(old('provinsi', $profile?->provinsi)); ?>" class="<?php echo e($inputClass); ?>">
            <?php $__errorArgs = ['provinsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="<?php echo e($errorClass); ?>"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label for="kota" class="<?php echo e($labelClass); ?>">Kota / Kabupaten <span class="text-red-500">*</span></label>
            <input type="text" name="kota" id="kota"
                value="<?php echo e(old('kota', $profile?->kota)); ?>" class="<?php echo e($inputClass); ?>">
            <?php $__errorArgs = ['kota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="<?php echo e($errorClass); ?>"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/pendaftar/profil/steps/step-2.blade.php ENDPATH**/ ?>