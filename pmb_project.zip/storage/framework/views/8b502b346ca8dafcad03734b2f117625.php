<?php $__env->startSection('title', 'Mapping Dokumen ke Jalur'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-2xl mx-auto">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-2xl font-bold">Mapping Dokumen</h1>
            <p class="text-sm text-gray-600 mt-1">
                <?php echo e($dokumen->nama); ?> (<?php echo e($dokumen->kode); ?>) &mdash; pilih jalur masuk yang mewajibkan dokumen ini.
            </p>
        </div>
        <a href="<?php echo e(route('admin.dokumen.index')); ?>" class="text-blue-600 hover:underline text-sm">&larr; Kembali</a>
    </div>

    <div class="bg-white shadow rounded-xl p-6">
        <form method="POST" action="<?php echo e(route('admin.dokumen.mapping.simpan', $dokumen)); ?>">
            <?php echo csrf_field(); ?>

            <div class="space-y-2">
                <?php $__empty_1 = true; $__currentLoopData = $jalur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <label class="flex items-center gap-3 rounded-lg border border-gray-200 px-4 py-3 hover:border-blue-400 hover:bg-blue-50/40 cursor-pointer">
                        <input type="checkbox" name="jalur[]" value="<?php echo e($j->id); ?>" class="mt-0.5"
                            <?php echo e(in_array($j->id, $terpilih) ? 'checked' : ''); ?>>
                        <span>
                            <span class="block text-sm font-medium text-gray-800"><?php echo e($j->nama); ?></span>
                            <span class="block text-xs text-gray-500">
                                <?php echo e($j->kode); ?> &middot; <?php echo e($j->punya_biaya_pendaftaran ? 'Berbayar' : 'Gratis'); ?>

                            </span>
                        </span>
                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500 text-sm">Belum ada jalur masuk.</p>
                <?php endif; ?>
            </div>

            <div class="mt-6 flex gap-3">
                <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-blue-700">
                    Simpan Mapping
                </button>
                <a href="<?php echo e(route('admin.dokumen.index')); ?>" class="border border-gray-300 text-gray-600 px-6 py-2 rounded-lg hover:bg-gray-50">Batal</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/admin/dokumen/mapping.blade.php ENDPATH**/ ?>