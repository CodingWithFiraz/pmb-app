<?php $__env->startSection('title', 'Berita'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <h1 class="text-3xl font-bold text-gray-800">Berita</h1>
    <p class="text-gray-600 mt-1">Informasi dan pengumuman terbaru seputar PNM Jakarta.</p>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
    <?php $__empty_1 = true; $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a href="<?php echo e(route('public.berita.detail', $item)); ?>"
            class="block bg-white shadow rounded-xl overflow-hidden hover:shadow-lg transition">
            <?php if($item->image_url): ?>
                <img src="<?php echo e($item->image_url); ?>" alt="<?php echo e($item->judul); ?>" class="w-full h-40 object-cover">
            <?php else: ?>
                <div class="w-full h-40 bg-gradient-to-br from-blue-600 to-blue-800 flex items-center justify-center text-white text-4xl font-bold">
                    <?php echo e(mb_substr($item->judul, 0, 1)); ?>

                </div>
            <?php endif; ?>

            <div class="p-5">
                <div class="text-xs text-gray-400 mb-1">
                    <?php echo e($item->published_at?->translatedFormat('d F Y')); ?> · <?php echo e($item->author); ?>

                </div>
                <h2 class="font-bold text-gray-800 leading-snug"><?php echo e($item->judul); ?></h2>
                <p class="text-gray-600 text-sm mt-2 line-clamp-3"><?php echo e($item->deskripsi); ?></p>
                <div class="text-sm text-blue-600 font-medium mt-3">Baca selengkapnya →</div>
            </div>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-gray-500 col-span-3">Belum ada berita yang dipublikasikan.</p>
    <?php endif; ?>
</div>

<div class="mt-8"><?php echo e($berita->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/public/berita/index.blade.php ENDPATH**/ ?>