<?php $__env->startSection('title', $berita->judul); ?>

<?php $__env->startSection('content'); ?>
<nav class="text-sm text-gray-500 mb-4">
    <a href="<?php echo e(route('home')); ?>" class="hover:text-blue-600">Beranda</a>
    <span class="mx-1">/</span>
    <a href="<?php echo e(route('public.berita')); ?>" class="hover:text-blue-600">Berita</a>
    <span class="mx-1">/</span>
    <span class="text-gray-700 truncate"><?php echo e($berita->judul); ?></span>
</nav>

<article class="bg-white shadow rounded-xl overflow-hidden">
    <?php if($berita->image_url): ?>
        <img src="<?php echo e($berita->image_url); ?>" alt="<?php echo e($berita->judul); ?>" class="w-full h-64 object-cover">
    <?php endif; ?>

    <div class="p-6 md:p-8">
        <div class="text-sm text-gray-400 mb-2">
            <?php echo e($berita->published_at?->translatedFormat('d F Y')); ?> · <?php echo e($berita->author); ?>

        </div>

        <h1 class="text-2xl md:text-3xl font-bold text-gray-800 leading-tight"><?php echo e($berita->judul); ?></h1>

        <div class="mt-4 text-gray-700 leading-relaxed whitespace-pre-line"><?php echo e($berita->deskripsi); ?></div>
    </div>
</article>

<div class="mt-6">
    <a href="<?php echo e(route('public.berita')); ?>" class="text-blue-600 hover:underline text-sm">← Kembali ke daftar berita</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/public/berita/show.blade.php ENDPATH**/ ?>