<?php $__env->startSection('title', 'Informasi PMB'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-bold mb-6">Informasi PMB</h1>

<?php $__empty_1 = true; $__currentLoopData = $periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="bg-white shadow rounded-xl p-6 mb-4">
        <div class="flex justify-between items-start">
            <div>
                <h2 class="font-bold text-lg"><?php echo e($period->nama); ?></h2>
                <div class="text-gray-600 text-sm mt-1">Tahun Akademik <?php echo e($period->tahun_akademik); ?></div>
            </div>
            <span class="px-3 py-1 rounded-full text-sm font-medium <?php echo e($period->is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'); ?>">
                <?php echo e($period->is_active ? '✓ Dibuka' : 'Ditutup'); ?>

            </span>
        </div>

        <div class="mt-3 grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
            <div><span class="text-gray-500">Buka:</span> <?php echo e($period->tanggal_mulai->format('d M Y')); ?></div>
            <div><span class="text-gray-500">Tutup:</span> <?php echo e($period->tanggal_selesai->format('d M Y')); ?></div>
        </div>

        <?php if($period->biayaPendaftaran->isNotEmpty()): ?>
            <div class="mt-4 border-t pt-3">
                <div class="text-xs font-semibold text-gray-500 uppercase mb-2">Biaya Pendaftaran per Jalur</div>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-2">
                    <?php $__currentLoopData = $period->biayaPendaftaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $biaya): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex justify-between bg-gray-50 rounded-lg px-3 py-2 text-sm">
                            <span class="text-gray-700"><?php echo e($biaya->jalur->kode); ?></span>
                            <span class="font-medium">
                                <?php echo e($biaya->nominal !== null ? 'Rp '.number_format($biaya->nominal, 0, ',', '.') : 'Gratis'); ?>

                            </span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p class="text-gray-500">Belum ada informasi periode tersedia.</p>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/public/info.blade.php ENDPATH**/ ?>