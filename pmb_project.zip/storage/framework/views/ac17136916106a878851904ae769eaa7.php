<?php $__env->startSection('title', 'Program Studi'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold">Program Studi</h1>
    <a href="<?php echo e(route('admin.program-studi.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700">+ Tambah</a>
</div>

<div class="bg-white shadow rounded-xl overflow-hidden">
    <table class="w-full text-sm">
        <thead class="bg-gray-50 text-gray-600">
            <tr>
                <th class="text-left px-4 py-3">Kode</th>
                <th class="text-left px-4 py-3">Nama</th>
                <th class="text-left px-4 py-3">Fakultas</th>
                <th class="text-left px-4 py-3">Jenjang</th>
                <th class="text-left px-4 py-3">Kuota</th>
                <th class="px-4 py-3"></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-t">
                    <td class="px-4 py-3 font-mono font-bold"><?php echo e($p->kode); ?></td>
                    <td class="px-4 py-3 font-medium"><?php echo e($p->nama); ?></td>
                    <td class="px-4 py-3 text-gray-600"><?php echo e($p->fakultas->nama); ?></td>
                    <td class="px-4 py-3 text-gray-600"><?php echo e($p->jenjang); ?></td>
                    <td class="px-4 py-3"><?php echo e($p->kuota ?? '∞'); ?></td>
                    <td class="px-4 py-3">
                        <div class="flex items-center gap-3">
                            <a href="<?php echo e(route('admin.program-studi.edit', $p)); ?>" class="text-blue-600 hover:underline text-xs">Edit</a>

                            <form method="POST" action="<?php echo e(route('admin.program-studi.destroy', $p)); ?>"
                                onsubmit="return confirm('Hapus program studi ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:underline text-xs">Hapus</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="text-center py-8 text-gray-500">Belum ada program studi.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="mt-4"><?php echo e($programs->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/admin/programs/index.blade.php ENDPATH**/ ?>