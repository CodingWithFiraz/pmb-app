<?php $__env->startSection('title', 'Hubungi Kami'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <h1 class="text-3xl font-bold text-gray-800">Hubungi Kami</h1>
    <p class="text-gray-600 mt-1">Informasi kontak panitia PMB <?php echo e($pengaturan['nama_singkat'] ?? 'PNM Jakarta'); ?>.</p>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    
    <div class="bg-white shadow rounded-xl p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Kontak</h2>

        <dl class="space-y-4 text-sm">
            <div>
                <dt class="text-gray-500">Kampus</dt>
                <dd class="font-medium text-gray-800 mt-0.5"><?php echo e($pengaturan['nama_kampus'] ?? '-'); ?></dd>
            </div>
            <div>
                <dt class="text-gray-500">Alamat</dt>
                <dd class="text-gray-700 mt-0.5 leading-relaxed"><?php echo e($pengaturan['alamat_kampus'] ?? '-'); ?></dd>
            </div>
            <div>
                <dt class="text-gray-500">Email</dt>
                <dd class="mt-0.5">
                    <a href="mailto:<?php echo e($pengaturan['email_kampus'] ?? ''); ?>" class="text-blue-600 hover:underline">
                        <?php echo e($pengaturan['email_kampus'] ?? '-'); ?>

                    </a>
                </dd>
            </div>
            <div>
                <dt class="text-gray-500">Telepon</dt>
                <dd class="text-gray-700 mt-0.5"><?php echo e($pengaturan['telepon_kampus'] ?? '-'); ?></dd>
            </div>
            <div>
                <dt class="text-gray-500">WhatsApp</dt>
                <dd class="text-gray-700 mt-0.5"><?php echo e($pengaturan['wa_kampus'] ?? '-'); ?></dd>
            </div>
            <div>
                <dt class="text-gray-500">Jam Operasional</dt>
                <dd class="text-gray-700 mt-0.5"><?php echo e($pengaturan['jam_operasional'] ?? '-'); ?></dd>
            </div>
        </dl>
    </div>

    
    <div class="lg:col-span-2 bg-white shadow rounded-xl overflow-hidden">
        <h2 class="text-xl font-bold text-gray-800 p-6 pb-4">Lokasi Campus</h2>

        <?php if(! empty($pengaturan['maps_embed'])): ?>
            <div class="w-full h-96 border-t border-gray-100">
                <iframe
                    src="<?php echo e($pengaturan['maps_embed']); ?>"
                    class="w-full h-full"
                    style="border:0"
                    allowfullscreen=""
                    loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade"
                    title="Peta lokasi <?php echo e($pengaturan['nama_kampus'] ?? 'kampus'); ?>"></iframe>
            </div>
        <?php else: ?>
            <div class="w-full h-96 border-t border-gray-100 flex items-center justify-center text-gray-500 bg-gray-50">
                Peta lokasi belum tersedia.
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/public/bantuan/kontak.blade.php ENDPATH**/ ?>