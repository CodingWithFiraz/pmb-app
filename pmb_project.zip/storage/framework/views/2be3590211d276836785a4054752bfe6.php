<?php $__env->startSection('title', 'Periode PMB'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold">Periode PMB</h1>
    <a href="<?php echo e(route('admin.periode.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700">+ Tambah Periode</a>
</div>

<div class="bg-white shadow rounded-xl overflow-hidden">
    <table class="w-full text-sm">
        <thead class="bg-gray-50 text-gray-600">
            <tr>
                <th class="text-left px-4 py-3">Nama</th>
                <th class="text-left px-4 py-3">Tahun Akademik</th>
                <th class="text-left px-4 py-3">Mulai</th>
                <th class="text-left px-4 py-3">Selesai</th>
                <th class="text-left px-4 py-3">Status</th>
                <th class="px-4 py-3"></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-t">
                    <td class="px-4 py-3 font-medium"><?php echo e($period->nama); ?></td>
                    <td class="px-4 py-3"><?php echo e($period->tahun_akademik); ?></td>
                    <td class="px-4 py-3"><?php echo e($period->tanggal_mulai->format('d/m/Y')); ?></td>
                    <td class="px-4 py-3"><?php echo e($period->tanggal_selesai->format('d/m/Y')); ?></td>
                    <td class="px-4 py-3">
                        <span class="px-2 py-0.5 rounded text-xs font-medium <?php echo e($period->is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'); ?>">
                            <?php echo e($period->is_active ? 'Aktif' : 'Nonaktif'); ?>

                        </span>
                        <div class="mt-1 text-xs text-gray-400"><?php echo e($period->pendaftaran_count); ?> pendaftar</div>
                    </td>
                    <td class="px-4 py-3">
                        <div class="flex items-center gap-3">
                            <a href="<?php echo e(route('admin.periode.edit', $period)); ?>" class="text-blue-600 hover:underline text-xs">Edit</a>

                            <form method="POST" action="<?php echo e(route('admin.periode.toggle', $period)); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="text-blue-600 hover:underline text-xs">
                                    <?php echo e($period->is_active ? 'Nonaktifkan' : 'Aktifkan'); ?>

                                </button>
                            </form>

                            <form method="POST" action="<?php echo e(route('admin.periode.destroy', $period)); ?>"
                                onsubmit="return confirm('Hapus periode ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:underline text-xs">Hapus</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="text-center py-8 text-gray-500">Belum ada periode.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="mt-4"><?php echo e($periods->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/admin/periods/index.blade.php ENDPATH**/ ?>