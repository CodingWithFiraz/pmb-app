<?php $__env->startSection('title', 'Pertanyaan Umum'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <h1 class="text-3xl font-bold text-gray-800">Pertanyaan Umum</h1>
    <p class="text-gray-600 mt-1">Jawaban atas pertanyaan yang sering diajukan calon mahasiswa.</p>
</div>

<?php $__empty_1 = true; $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="mb-6 last:mb-0">
        <h2 class="text-lg font-bold text-gray-700 mb-3"><?php echo e($kategori); ?></h2>

        <div class="space-y-2">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <details class="group bg-white shadow rounded-xl overflow-hidden">
                    <summary class="flex items-center justify-between gap-4 px-5 py-4 cursor-pointer font-medium text-gray-800 hover:bg-blue-50/50 list-none">
                        <span><?php echo e($item->pertanyaan); ?></span>
                        <span class="shrink-0 text-blue-600 transition-transform group-open:rotate-45 text-xl leading-none">+</span>
                    </summary>
                    <div class="px-5 pb-5 text-gray-600 leading-relaxed border-t border-gray-100 pt-4">
                        <?php echo e($item->jawaban); ?>

                    </div>
                </details>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p class="text-gray-500">Belum ada pertanyaan yang tersedia.</p>
<?php endif; ?>

<div class="mt-8 bg-blue-50 border border-blue-200 rounded-xl p-6 text-center">
    <p class="text-blue-900">Belum menemukan jawabannya?</p>
    <a href="<?php echo e(route('public.bantuan.kontak')); ?>" class="text-blue-600 hover:underline font-medium">Hubungi panitia PMB →</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/public/bantuan/faq.blade.php ENDPATH**/ ?>