<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    
    ->withMiddleware(function (Middleware $middleware) {
    $middleware->alias([
        'admin'    => \App\Http\Middleware\EnsureUserIsAdmin::class,
        'pendaftar' => \App\Http\Middleware\EnsureUserIsPendaftar::class,
    ]);

    $middleware->redirectUsersTo(function () {
        return auth()->user()?->isAdmin()
            ? route('admin.dashboard')
            : route('pendaftar.dashboard');
    });

    // Notifikasi Midtrans dipanggil dari server Midtrans tanpa token CSRF.
    $middleware->validateCsrfTokens(except: [
        'midtrans/callback',
    ]);
})
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();

    