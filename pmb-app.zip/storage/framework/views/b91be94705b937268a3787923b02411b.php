<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'PMB'); ?> — Penerimaan Mahasiswa Baru</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-gray-50 text-gray-800">

<nav class="bg-blue-700 text-white shadow">
    <div class="max-w-6xl mx-auto px-4 py-3 flex justify-between items-center">
        <a href="<?php echo e(route('home')); ?>" class="font-bold text-lg">🎓 PMB Online</a>
        <div class="flex gap-4 items-center text-sm">
            <a href="<?php echo e(route('public.info')); ?>" class="hover:underline">Informasi</a>
            <a href="<?php echo e(route('public.programs')); ?>" class="hover:underline">Program Studi</a>
            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->isAdmin()): ?>
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="hover:underline">Admin</a>
                <?php else: ?>
                    <a href="<?php echo e(route('applicant.dashboard')); ?>" class="hover:underline">Dashboard Saya</a>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="bg-white text-blue-700 px-3 py-1 rounded text-sm font-medium hover:bg-blue-50">Keluar</button>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="hover:underline">Masuk</a>
                <a href="<?php echo e(route('register')); ?>" class="bg-white text-blue-700 px-3 py-1 rounded font-medium hover:bg-blue-50">Daftar</a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<main class="max-w-6xl mx-auto px-4 py-8">
    <?php if(session('success')): ?>
        <div class="mb-4 bg-green-100 border border-green-400 text-green-800 px-4 py-3 rounded">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="mb-4 bg-red-100 border border-red-400 text-red-800 px-4 py-3 rounded">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('info')): ?>
        <div class="mb-4 bg-blue-100 border border-blue-400 text-blue-800 px-4 py-3 rounded">
            <?php echo e(session('info')); ?>

        </div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>
</main>

<footer class="mt-16 bg-gray-800 text-gray-400 text-sm text-center py-6">
    <p>© <?php echo e(date('Y')); ?> PMB Online. Sistem Penerimaan Mahasiswa Baru.</p>
</footer>

</body>
</html><?php /**PATH C:\Users\afgan\Documents\On process\Kampus(kelas)\Tugas Kuliah\S7\Kompotasi Awan\aplikasi pendaftaran mahasiswa\pmb-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>